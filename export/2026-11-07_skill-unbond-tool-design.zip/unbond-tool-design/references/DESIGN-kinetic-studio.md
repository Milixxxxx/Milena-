---
name: Kinetic Studio
colors:
  surface: '#0f141b'
  surface-dim: '#0f141b'
  surface-bright: '#353941'
  surface-container-lowest: '#090e15'
  surface-container-low: '#171c23'
  surface-container: '#1b2027'
  surface-container-high: '#252a32'
  surface-container-highest: '#30353d'
  on-surface: '#dee2ed'
  on-surface-variant: '#bbcac1'
  inverse-surface: '#dee2ed'
  inverse-on-surface: '#2c3138'
  outline: '#86948c'
  outline-variant: '#3c4a43'
  surface-tint: '#4ddeac'
  primary: '#5e9590'
  on-primary: '#003827'
  primary-container: '#5e9590'
  on-primary-container: '#00573f'
  inverse-primary: '#006c4f'
  secondary: '#ffb1c0'
  on-secondary: '#600e2a'
  secondary-container: '#812942'
  on-secondary-container: '#ff9cb0'
  tertiary: '#ffceb1'
  on-tertiary: '#512400'
  tertiary-container: '#ffa86f'
  on-tertiary-container: '#783b09'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6efbc7'
  primary-fixed-dim: '#4ddeac'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#ffd9df'
  secondary-fixed-dim: '#ffb1c0'
  on-secondary-fixed: '#3f0016'
  on-secondary-fixed-variant: '#7e2740'
  tertiary-fixed: '#ffdbc7'
  tertiary-fixed-dim: '#ffb689'
  on-tertiary-fixed: '#311300'
  on-tertiary-fixed-variant: '#723604'
  background: '#0f141b'
  on-background: '#dee2ed'
  surface-variant: '#30353d'
  canvas-deep: '#000000'
  canvas-surface: '#0E131A'
  canvas-elevated: '#171E28'
  text-primary: '#FFFFFF'
  accent-mint: '#5e9590'
  accent-crimson: '#7D263F'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 72px
    fontWeight: '700'
    lineHeight: 80px
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  code-md:
    fontFamily: Space Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-caps:
    fontFamily: Space Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 3rem
  margin-sm: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style

This design system embodies an editorial, high-contrast, modern agency aesthetic tailored for digital products and creative tech studios. It fuses the discipline of structural brutalism with the refinement of contemporary typography and rich chromatic accents. 

The visual voice is confident, sharp, and intentionally composed. Whitespace serves as an active structural element rather than passive margin. Bold, monolithic typography contrasts directly with functional monospace metadata and clean sans-serif body copy. The emotional tone evokes technical precision, creative fearlessness, and premium craftsmanship. It balances stark dark canvas regions with deep crimson and crisp mint highlights to direct attention with surgical intent.

## Colors

The palette is engineered around high contrast, precision lighting, and deliberate chromatic accents on an obsidian canvas. 

- **Primary (`#5e9590`)**: A vibrant digital mint serving as the interactive beacon. It is applied to primary actions, interactive highlights, active indicators, and high-priority states.
- **Secondary (`#7D263F`)**: A deep, saturated crimson offering sophisticated counter-weight. Used for contextual focus states, badges, narrative block anchors, and editorial treatments.
- **Neutral (`#0E131A`)**: A deep ink-navy substrate that provides atmospheric softness over pure pitch black, preventing visual fatigue while preserving dramatic depth.
- **Named Colors**: `#000000` (Pitch Black) anchors full canvas backgrounds, while `#171E28` acts as an elevated interactive card surface. `#FFFFFF` supplies uncompromising legibility for primary display and text content.

## Typography

The typographic hierarchy uses a triad structure:
1. **Headlines (`Space Grotesk`)**: Geometric and modern with tight tracking (`-0.02em` to `-0.04em`) to project architectural impact and forward-thinking agency authority.
2. **Body (`Plus Jakarta Sans`)**: Clean, highly readable, humanist neo-grotesque that handles dense copy with effortless clarity and natural rhythm.
3. **Data & Metadata (`Space Mono`)**: Technical and disciplined, uppercase tracking is widened (`0.08em`) for category stamps, indexes, metrics, status tags, and inline figures.

On mobile viewports, display scales compress aggressively to eliminate accidental word wrapping while preserving high-contrast visual weight.

## Layout & Spacing

The layout is built upon an 8px modular baseline coupled with a 12-column fluid grid system on desktop, collapsing to an 8-column grid on tablet and a 4-column grid on mobile.

- **Desktop (>= 1280px)**: 12 columns with `margin: 3rem` (or max-width containment at `1440px`), with `gutter: 1.5rem`.
- **Tablet (768px - 1279px)**: 8 columns with `margin: 2rem` and `gutter: 1.25rem`.
- **Mobile (< 768px)**: 4 columns with `margin-sm: 1.25rem` and `gutter-sm: 1rem`.

Outer sectional padding leverages `space-2xl` and above to reinforce spatial breathing room. Grid columns are separated by subtle linear structural boundaries, allowing modular layout blocks to assemble like technical drafting grids.

## Elevation & Depth

Elevation rejects soft, generic blurred drop shadows in favor of **structural containment, low-contrast hairline borders, and chromatic planar offsets**:

- **Hairline Outlines**: Boundaries rely on crisp `1px solid rgba(255, 255, 255, 0.1)` strokes rather than diffused drops. This defines components with razor precision against the dark substrate.
- **Tonal Layering**: Depth is achieved through surface darkness tiers: `#000000` (Canvas) -> `#0E131A` (Card Base) -> `#171E28` (Interactive Hover / Elevated Drawer).
- **Hard Technical Casts**: For floating modals or dropdown overlays, an intentional offset shadow is used (`0 8px 0px rgba(0, 0, 0, 0.6)` combined with a `1px` border of `rgba(94,149,144, 0.2)`), reflecting a technical, tactile aesthetic rather than soft blur-heavy realism.

## Shapes

The shape hierarchy follows a crisp, near-industrial radius profile (`roundedness: 1`). 

- Default elements (buttons, inputs, chips, compact cards) utilize `0.25rem` (4px) corner radii.
- Large containers, modals, and featured media blocks take `0.5rem` (8px).
- Status pips and isolated micro-indicators remain fully circular (`9999px`).

This controlled softness avoids the severe harshness of zero-radius brutalism while maintaining the razor-sharp posture of modern digital design tools.

## Components

### Buttons
- **Primary**: Solid mint background (`#5e9590`), jet-black text (`#000000`), font `Space Mono` 13px uppercase bold with `0.04em` tracking. Padding: `12px 24px`. Border radius: `4px`. Hover triggers a crisp translation up-and-left by 2px with an offset drop shadow.
- **Secondary / Ghost**: Transparent fill, 1px solid `rgba(255, 255, 255, 0.2)` border, text `#FFFFFF`. Hover state: border color turns to `#5e9590` with text color shifting to `#5e9590`.
- **Tertiary / Destructive**: Tinted crimson fill (`rgba(125, 38, 63, 0.2)`), 1px solid `#7D263F` border, text `#FFFFFF`.

### Chips & Badges
- Constructed with `Space Mono` 11px uppercase.
- Padding: `4px 10px`. 
- Neutral chips use `#171E28` background with a subtle `rgba(255, 255, 255, 0.1)` border. 
- Highlight chips feature `#5e9590` text on `rgba(94,149,144, 0.1)` background with `1px solid rgba(94,149,144, 0.3)`.

### Lists
- Dividers between list items use hairline `1px solid rgba(255, 255, 255, 0.08)`.
- List rows feature monospace index labels (e.g., `// 01`, `// 02`) rendered in `label-sm` with text color muted (`rgba(255, 255, 255, 0.4)`).
- Hover state on list rows triggers a subtle background transition to `#171E28`.

### Form Controls (Checkboxes & Radios)
- Square (4px radius) for checkboxes, circular for radios.
- Unchecked: `1px solid rgba(255, 255, 255, 0.3)` on `#0E131A`.
- Checked: Fill with `#5e9590`, checkmark icon drawn in pitch black (`#000000`). Focus rings feature an outer `2px` offset stroke in `rgba(94,149,144, 0.4)`.

### Input Fields
- Background `#0E131A`, border `1px solid rgba(255, 255, 255, 0.15)`, radius `4px`.
- Padding: `12px 16px`.
- Text color `#FFFFFF` in `Plus Jakarta Sans`. 
- Placeholder text in `rgba(255, 255, 255, 0.35)`.
- Floating label or pre-header in `Space Mono` 11px uppercase (`label-caps`).
- Focused state: border color transitions cleanly to `#5e9590` with zero blur glow.

### Cards
- Surface: `#0E131A`. Border: `1px solid rgba(255, 255, 255, 0.08)`. Radius: `8px`.
- Padding: `24px` (`space-lg`).
- Interactive cards elevate border luminance to `rgba(94,149,144, 0.4)` on hover, with headers shifting subtly.

### Metric Callouts & Agency Data Blocks
- Purpose-built component for digital agency portfolios and SaaS telemetry. Features huge display numbers (`headline-lg`) paired with `label-caps` descriptions and a top hairline separator in accent mint or crimson.