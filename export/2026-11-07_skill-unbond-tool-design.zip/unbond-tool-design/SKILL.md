---
name: unbond-tool-design
description: Das UNBOND-Tool-Design (Stitch-Vorlage "Kinetic Studio", wie im Klarheitscheck umgesetzt) für neue Übungen, Tools, Webapps, Dashboards und Bildschirme von UNBOND. Dunkles Tinten-Navy, Mint als Aktionsfarbe, Crimson für Notfall, Space Grotesk / Plus Jakarta Sans / Space Mono. Nutzen, wenn etwas "im Tool-Design", "im Stitch-Design", "wie der Klarheitscheck" oder "im Kinetic-Studio-Stil" für UNBOND gestaltet oder gebaut werden soll. Nicht für die normalen Website-Seiten (die nutzen das Nothing-Design) und nicht für Social-Media-Grafiken (UNBOND-Regelwerk).
---

# UNBOND Tool-Design („Kinetic Studio“)

Das verbindliche Aussehen aller UNBOND-Tools und Übungen unter `unbond.de/tools/`. Quelle ist die live geprüfte Umsetzung im Klarheitscheck (`tools/phase-2/klarheitscheck/`). Die ursprüngliche Stitch-Beschreibung liegt in `references/DESIGN-kinetic-studio.md`. Bei Widerspruch gilt die Umsetzung im Klarheitscheck und damit `assets/unbond-tool.css`.

## Wann welches Design

| Was | Design |
|---|---|
| Tools, Übungen, Webapps, Tool-Phasenseiten | **dieses Design** |
| Normale Seiten auf unbond.de (wissen, klarheit, blog, Leseproben) | Nothing-Design (`unbond-nothing.css`), nicht dieses |
| Social Media, Grafiken, Produkte | UNBOND-Regelwerk (Navy, Glas, Nebula) |

## So baust du damit

1. Kopiere `assets/unbond-tool.css`, `assets/fonts/`, `assets/logo-wortmarke.webp` und `assets/sos.webp` neben die neue Seite (CSS erwartet die Schriften in `fonts/`).
2. Starte mit `assets/vorlage.html`. Sie enthält jeden Baustein einmal. Übernimm Struktur und Klassen, ändere nur Inhalte.
3. Keine neuen Farben, Schriften oder Radien erfinden. Fehlt ein Baustein, aus den Tokens unten zusammensetzen und im Bericht nennen.
4. Nichts von fremden Servern laden: keine Google Fonts, kein Tailwind-CDN, keine Icon-Schrift. Icons als SVG-Symbole wie in der Vorlage (Material-Symbols-Pfade).
5. Für die technische Fertigstellung (Datenschutz, Tracking, Sperre, Prüfliste) danach den Skill `unbond-webapp-umbau` nutzen.

## Tokens

**Farben**
| Rolle | Wert | Variable |
|---|---|---|
| Seitenhintergrund | `#0f141b` | `--bg` |
| Kopfzeile, tiefste Ebene | `#000000` | `--deep` |
| Karte | `#0e131a` | `--surface` |
| Erhöhte Fläche (Kacheln, Felder) | `#171e28` | `--elevated` |
| Aktion, Hauptknopf | Mint `#5e9590`, Hover `#5e9590` | `--mint`, `--primary` |
| Notfall, Löschen, Gewicht | Crimson `#7d263f`, Hover `#7d263f` | `--crimson` |
| Warnung, Wartezustand, zweiter Akzent | Rosa `#ffb1c0` | `--pink` |
| Notrufnummern | `#ffb4ab` | `--error` |
| Text / Nebentext / leise | `#dee2ed` / `#bbcac1` / `#86948c` | `--text`, `--text-var`, `--outline` |
| Haarlinien | `rgba(255,255,255,.1)` und `.05`, Trennlinie `#3c4a43` | `--hair`, `--hair2`, `--line` |

**Schriften** (genau drei)
- Überschriften: Space Grotesk 600, eng gesetzt (`-0.02em`). `.h-md` 32/40, `.h-sm` 24/32.
- Fließtext: Plus Jakarta Sans 400, 16/24, Einleitung (`.lead`) Zeilenhöhe 1.65.
- Beschriftungen, Zahlen, Status: Space Mono. `.caps` 12 px, fett, Versalien, `0.08em`. `.mono-sm` 11 px. Gern mit `// ` davor („// Dauer“).

**Form und Tiefe**
- Radien: 4 px für Knöpfe, Felder, Chips, kleine Kacheln. 6–8 px für Optionen und Flächen. 12 px für Karten und Dialoge.
- Tiefe nur über Flächenstufen (`#000` → `#0e131a` → `#171e28`) und 1-px-Haarlinien. Keine weichen Schlagschatten, kein Glas.
- Mobil zuerst: Inhalt `max-width: 42rem`, Ränder 16 px, ab 640 px 24 px. Tippflächen mindestens 44 px.

## Bausteine (Klassen in `unbond-tool.css`)

| Baustein | Klasse | Einsatz |
|---|---|---|
| Kopfzeile | `.bar`, `.bar-l`, `.bar-r`, `.bar-tag` | Logo, „// Phase · Name“, Neustart, Notfall |
| Notfall-Knopf | `.sos-btn` | immer oben rechts, öffnet `.modal` |
| Karte | `.card`, `.card--hi`, `.card--crimson`, `.glow` | Hauptinhalt je Schritt |
| Kicker | `.kicker.caps` | Icon plus Kategorie über dem Titel |
| Kennzahlen | `.meta` | 2 bzw. 4 Kacheln mit Schritten, Dauer, Daten, Methode |
| Schrittfolge | `.steps` | nummerierte Schritte, Zahlen in Mint |
| Hinweis | `.note`, `.note--pink` | Datenschutz, Vorab-Hinweis, Warnung |
| Fortschritt | `.prog`, `.track` | „Schritt 01 / 05“ plus Balken |
| Eingabe | `.flabel`, `.field` | Textfelder, Fokus Mint ohne Glühen |
| Mehrfachauswahl | `.chips`, `.chip[aria-pressed]` | Häkchen in Mint |
| Einfachauswahl | `.opts`, `.opt[aria-pressed]`, `.key` | A/B/C-Antworten |
| Gegenüberstellung | `.split`, `.pane--there`, `.pane--wait`, `.vs` | Mint gegen Rosa |
| Kernsatz | `.quote` | Space Grotesk 18, Mint-Kante |
| Knöpfe | `.btn`, `.btn--ghost`, `.btn--crimson`, `.btn--block`, `.navrow` | Mint = weiter, Ghost = zurück, Crimson = löschen |
| Kacheln | `.tiles`, `.tile` | Weiterführende Wege |
| Notfall-Dialog | `.modal`, `.modal-box`, `.hot`, `.num`, `.num--mint` | vier Nummern |
| Über die Übung | `.about` | Pflichtabschnitt am Ende |
| Fußzeile | `footer` | Hinweis, Impressum, Datenschutz |

## Pflicht in jedem Tool

- Notfall-Dialog mit 110, 112, Telefonseelsorge 0800 111 0 111, Hilfetelefon Gewalt gegen Frauen 08000 116 016, von jedem Bildschirm mit einem Tipp erreichbar.
- Satz „Selbsthilfe, kein Ersatz für Therapie oder Krisenhilfe.“
- Datenhinweis: „Deine Eingaben bleiben auf deinem Gerät.“ oder „Deine Eingaben werden nicht gespeichert.“
- Abschnitt „Über diese Übung“ und `<script type="application/json" id="tool-meta">`, Unbekanntes als `null`.
- `prefers-reduced-motion` respektieren (in der CSS schon enthalten).

## Nicht tun

- Kein Gelb als UI-Farbe, keine Emojis als Dekoration, keine weiteren Schriften.
- Mint nicht für Fließtext-Flächen, nur für Aktionen, Zahlen, aktive Zustände und Kicker.
- Crimson nicht als Hauptknopf für „Weiter“, nur für Notfall und Löschen.
- Keine Scores, Prozentwerte oder Diagnosen als Ergebnis von Selbsteinschätzungen.
- Nicht die Website-Seiten auf dieses Design umstellen.

## Abweichungen von der Stitch-Vorlage (bewusst, Stand Klarheitscheck)

- Hauptknopf: Hover hellt auf (`#5e9590`) statt Verschiebung mit Schatten.
- Seitenhintergrund `#0f141b` statt reinem Schwarz, Schwarz nur in der Kopfzeile.
- Knopfschrift 12 px statt 13 px.
