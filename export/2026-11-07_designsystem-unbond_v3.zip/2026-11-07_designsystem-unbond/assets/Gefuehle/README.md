Gefühlsbilder (Angst, Ohnmacht, Trauer, Verzweiflung, Wut) als halbtransparenter Hintergrund in `.nt-tile--img` über `--tile-img`, Deckkraft .36, Hover .52. Nie als Vollbild, nie mit Text darauf.
