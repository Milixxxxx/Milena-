Wortmarke UNBOND (weiße Schrift, Bordeaux- und Goldzeichen) für Kopfzeile und Footer auf schwarzem Grund. `logo.png` ist das Favicon. Nie neu zeichnen oder einfärben.
