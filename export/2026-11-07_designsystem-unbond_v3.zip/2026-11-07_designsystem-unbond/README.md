UNBOND ist ein deutschsprachiges Selbsthilfeprogramm für lesbische und queere Frauen nach toxischen Beziehungen. Dieses System beschreibt alles, was auf **unbond.de** zu sehen ist: drei Gestaltungswelten, die Bereichsfarben je Seite und die Bausteine jeder Welt. Werte stammen aus dem Upload-Ordner `UNBOND_upload_komplett_2026-11-04`, Stand 07.11.2026.

## Welche Welt gilt wo

| Welt | Seiten | Kennzeichen | Stildateien |
|---|---|---|---|
| **Website (Nothing-Design)** | wissen, klarheit, toxikometer, report, Tests, heilungskompass, blog, no-contact, tools-Übersicht und Phasenseiten, Leseprobe, impressum, datenschutz | Schwarz, flach, Poppins, Bordeaux-Knöpfe, Bereichsfarbe als Leitlinie | `unbond-nothing.css` + `unbond-nothing-poppins.css` + `unbond-bereich.css`, auf älteren Seiten zusätzlich `unbond-nothing-skin.css` |
| **Tools (Stitch „Kinetic Studio“)** | Übungen unter `tools/phase-N/<name>/`, Vorlage Klarheitscheck | Tinten-Navy, Grün-Aktion (`#5e9590`), Crimson-Notfall, Space Grotesk / Plus Jakarta Sans / Space Mono | `app.css` je Tool; Skill `unbond-tool-design` |
| **Startseite** | index.html | eigener Stapel aus 20 Dateien, am Ende vereinheitlicht durch `unbond-index-typo.css` und `unbond-nothing-buttons.css` | wird nur nach Freigabe geändert |

Social Media, Produkte und Grafiken folgen weiter dem UNBOND-Regelwerk (Navy, Glas, Nebula). Dieses System gilt nur für die Website und die Tools.

## Inhalt und Ton

- Deutsch, Du-Ansprache, einfache Sprache. Fachbegriffe beim ersten Mal erklären.
- Suchsprache der Zielgruppe wörtlich nutzen: „war meine Beziehung toxisch“, „warum vermisse ich sie noch“.
- Nie „Opfer“ für Betroffene, keine Ferndiagnose über eine Person, keine Heilversprechen. Ergebnisse beschreiben Muster („Dein Ergebnis zeigt Merkmale von …“).
- Bezahlprodukte nie „Freebie“ nennen. Kauflinks führen auf die Angebotsseite, nie direkt in den Checkout, nie mit Gutschein-Parameter.
- Keine Emojis als Dekoration, keine Gedankenstriche als Stilmittel.
- Jede Seite trägt die Krisenleiste: „Kein Ersatz für Therapie“, Telefonseelsorge 0800 111 0 111, Hilfetelefon Gewalt 08000 116 016. Tools zusätzlich Notruf 110 und 112 im Notfall-Dialog.

## Farbe

**Website.** Grund `nt-black`, Flächen `nt-surface`, Linien `nt-line` und `nt-line-soft`. Text in `nt-text`, Nebentext in `nt-text-2`, Meta in `nt-text-3`. Knöpfe in `nt-red` mit Hover `nt-red-hover`. `nt-gold` nur für Zahlen. `nt-sage` für kostenlose Wege. Kein Gelb als Fläche, kein Glas, kein Nebula.

**Bereichsfarben.** Jede Seite setzt `body[data-bereich]`. Daraus entstehen `--ub-c` (Leitfarbe) und `--ub-sig` (Signalfarbe):

| data-bereich | Seiten | `--ub-c` | `--ub-sig` |
|---|---|---|---|
| `start` | index.html | `ub-start` | alle Grüntöne sind `nt-sage` (`#5e9590`) |
| `wissen` | wissen.html (00 Übersicht) | `ub-wissen` | `ub-wissen-sig` |
| `klarheit` | klarheit, toxikometer, report, narzissmus-test, bindungsmuster-test, heilungskompass, spielautomat, Leseprobe (01 Erkennen) | `ub-klarheit` | = Leitfarbe |
| `nocontact` | no-contact/index.html (02 Abstand halten) | `ub-nocontact` | = Leitfarbe |
| `blog` | blog/index.html und alle Artikel (03 Verstehen) | `ub-blog` | = Leitfarbe |
| `tools` | tools/index.html und Phasenseiten (04 Weitergehen) | `ub-tools` | = Leitfarbe |
| ohne | blick-ins-buch, impressum, datenschutz, Klarheitscheck | Fallback `nt-red-hover` | – |

Die **Leitfarbe** färbt: die 2px-Linie unter der Kopfzeile, den aktiven Menüpunkt, die erste `.nt-label` im Seitenkopf, den aktiven Schritt im Wegweiser, den Zurück-Knopf im Hover. Die **Signalfarbe** färbt: `h1 em`, Aufzählungszeichen, Fortschrittsbalken, Belegzeilen im Zeitstrahl, Antwortknöpfe im aktiven Zustand. **Zahlen bleiben immer `nt-gold`, Knöpfe immer Bordeaux.**

**Weiter-Karten** tragen die Farbe ihres Ziels: `weiter-tox`, `weiter-narzissmus`, `weiter-bindung`, `weiter-kompass`, `weiter-spiel`, `weiter-nocontact`, Buch `nt-gold`.

**Tools.** Grund `tool-bg`, Kopfzeile `tool-deep`, Karte `tool-surface`, erhöht `tool-elevated`. Hauptknopf `tool-mint` (`#5e9590`) mit schwarzer Schrift. `tool-pink` für Warnung und Wartezustand, `tool-crimson` nur für Notfall und Löschen.

## Typografie

- **Website:** nur Poppins. `unbond-nothing-poppins.css` erzwingt sie auf allem in `body.nt`. Kopf `web-h1` (Gewicht 400), Abschnitte `web-h2` (500), Einleitung `web-lead`, Text `web-body`, Labels `web-label` in Versalien. Kernsätze `web-kern` in Playfair Italic, Farbe `lp-kern`; sie brauchen einen Selektor ab `html body.nt …`, sonst gewinnt Poppins.
- **Startseite:** Poppins in fünf Größen (`start-h1`, `start-h2`, `start-text`, `start-small`, Preis in h2-Größe), Space Mono für Knöpfe (`start-mono`), Playfair Italic für Zitate (`start-zitat`).
- **Tools:** Space Grotesk für Überschriften (`tool-h-md`, `tool-h-sm`), Plus Jakarta Sans für Text (`tool-body`), Space Mono für Labels und Knöpfe (`tool-caps`, `tool-mono-sm`, gern mit „// “ davor).
- Höchstens drei Schriften je Welt. Alle Dateien liegen lokal, keine Google Fonts.

## Raum, Form, Tiefe

- Website: Inhalt `space-wrap` mit Rand `space-gutter` (mobil `space-gutter-sm`). Kopfzeile `space-nav`. Kacheln Innenabstand `space-tile`, Raster `space-grid`.
- Radien: `radius-4` für alles Bedienbare, `radius-8` für Kacheln und Karten. Tools zusätzlich `radius-6` und `radius-12`.
- Keine Schatten (`shadow-none`). Tiefe nur über Flächenstufen und 1px-Linien.
- Jede Tippfläche mindestens `space-touch`.

## Bewegung

Kurz und funktional: `.18s ease` für Knöpfe und Kacheln, `.25s` für Weiter-Karten, `.7s cubic-bezier(.16,1,.3,1)` für die Einblendung im Zeitstrahl. Bei `prefers-reduced-motion` schaltet `unbond-nothing.css` alle Übergänge ab, der Zeitstrahl erscheint sofort.

## Fokus und Barrierefreiheit

Fokus: `outline: 2px solid` `nt-white`, Offset 4px (Zurück-Knopf: Leitfarbe; Tools: `tool-primary`). Skip-Link `.nt-skip` auf jeder Seite. Belastende interaktive Teile haben „Diesen Teil überspringen“.

## Bildsprache und Icons

- **Logo:** Wortmarke `assets/Logos/logo-wortmarke.webp` in Kopfzeile (64px hoch, mobil 48px) und Footer; `logo.png` als Favicon.
- **Gefühlsbilder** (`assets/Gefuehle`) als halbtransparenter Kachel-Hintergrund über `--tile-img`, Deckkraft .36, Hover .52.
- **Icons** (`assets/Icons`): Bildmarken, auf der Website per CSS-Maske in der Kartenfarbe eingefärbt. Tools nutzen ein SVG-Sprite mit Material-Symbols-Pfaden. Keine Icon-Schrift.
- Menü-Knopf nutzt das Zeichen ☰; sonst keine Emojis.

## Bekannte Abweichungen (Stand 07.11.2026)

Diese Stellen weichen vom System ab und sind Kandidaten fürs Aufräumen:
- Cookie-Banner (`unbond-consent.css`) ist noch altes Navy-Glas mit gelbem Fokus und 🍪 im Titel; die Startseite hat ein zweites, anderes Banner.
- Mauve und Terrakotta kommen je in drei Varianten vor. Bordeaux und Grün sind seit 07.11.2026 bereinigt (siehe unten).
- Radien 12, 14, 16, 18 und 22px neben der 4/8-Regel (Weiter, Buch-Block, Quellen, Startseite).
- `blick-ins-buch.html` lädt kein Nothing-CSS (altes Navy-Design); `tools/spielautomat.html` hat kein `body.nt`.
- Space Grotesk und Space Mono werden auf der Website geladen, aber nicht genutzt.
- Ungenutzt: `favicon.svg`, `assets/portraits/`, `assets/card-*.webp`, `hero-final-first-frame.jpg`.

## Ein Bordeaux, ein Grün (Entscheidung 07.11.2026)

- **Bordeaux:** nur `#7d263f`. Gilt für Knöpfe, Linien, Kästen, Notfall, Weiter-Karte ToxiCometer. Kein heller Hover-Ton mehr: Hover zeigt sich durch Füllung, weiße Schrift oder Bewegung.
- **Grün:** nur `#5e9590` (Blaugrün in Richtung Türkis). Gilt für kostenlose Wege, Signalfarbe wissen, Startseite, Bereich tools, Weiter-Karten Kompass, Spielautomat und No Contact, und für den Hauptknopf der Stitch-Tools (vorher Mint `#62f0bd` / `#3fd3a2`).
- Bordeaux nie als Schriftfarbe: auf Bordeaux-Karten steht die Schrift in `#e8e8e8`.
- Bewusst nicht umgestellt: helle Rosa-Schrift für Lesbarkeit (SOS-Knopf und Hotline in den Tools `#ffb1c0`, `#ffb4ab`), Warnrot im Spielautomaten (`#b83025`), sehr dunkle Hintergrundtöne, fast weiße Schriften mit leichtem Grünstich und Mauve `#b4869f` als Farbe des Bereichs Klarheit.
