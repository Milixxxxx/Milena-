# UNBOND Website · Design-Token- und Komponenten-Inventar

Stand: 07.11.2026 · Quelle: `H:\Meine Ablage\Milena_os\unbond-os\02_Landingpage\UNBOND_upload_komplett_2026-11-04` (nur gelesen)
Nicht erfasst: `_test_schrift*`, gesperrte Tools (flashback-stopper, community-mapping, bindungsmuster-quiz).
Methode: CSS-Dateien und Inline-`<style>` gelesen, `<body>`- und `<link>`-Tags aller 33 HTML-Seiten ausgewertet. Endwerte bei Kaskaden-Konflikten sind **per Spezifität berechnet, nicht im Browser gemessen** (lokale Vorschau lud kein CSS). Unsicheres ist mit [unbekannt] markiert.

---

## 0 · Welche Seite gehört zu welcher Welt (tatsächlich geladen)

| Welt | Seiten | Stack (Reihenfolge laut `<link>`) |
|---|---|---|
| 1a Nothing „pur“ (`body.nt`, ohne Skin) | wissen.html, leseprobe-wolf-im-schafskittel.html, tools/index.html, tools/phase-1…6/index.html | unbond-nothing.css → unbond-nothing-poppins.css → unbond-consent.css → unbond-bereich.css → (unbond-weg-tl.css nur tools/index) → unbond-zurueck.css → unbond-footer.css + Inline |
| 1b Nothing + Skin (`body.nt.nt-skin`) | klarheit, toxikometer, report, narzissmus-test, bindungsmuster-test, heilungskompass, datenschutz, impressum, blog/index, 11 Blogartikel, no-contact/index | Altlast (style.css, unbond-shell.css, unbond-web.css, unbond-pages.css, report.css, report-results.css, tox-mobile-radar.css, blog-article.css, no-contact.css) → unbond-nothing.css → unbond-nothing-skin.css → unbond-nothing-poppins.css → (unbond-nothing-alt.css: datenschutz, impressum, heilungskompass, no-contact) → unbond-bereich.css → (unbond-weg-tl.css: klarheit, blog/index, no-contact) → unbond-zurueck.css → (unbond-weiter.css: Tests, Report, Kompass) → unbond-footer.css |
| 1c Sonderfall Spielautomat | tools/spielautomat.html | tools.css → poppins → nothing-alt → nothing → poppins (doppelt) → bereich → zurueck → weiter → footer. **Body ohne Klasse `nt`**: alle `body.nt`-Regeln greifen nicht, nur unskopierte (`.topnav`, `.nt-trust`, `.nt-wrap`). |
| 1d Sonderfall Blick ins Buch | blick-ins-buch.html | **Kein Nothing-CSS.** Nur unbond-zurueck.css, unbond-footer.css + 2 eigene Inline-`:root`-Blöcke (Altdesign Navy/Glas). |
| 2 Stitch „Kinetic Studio“ | tools/phase-2/klarheitscheck/index.html | app.css → unbond-zurueck.css (kein data-bereich) |
| 3 Startseite | index.html (`data-page="sales" data-bereich="start"`) | site-v21 → redesign-v32 → glass-v33 → reference-type → ux-refinement → 7 Inline-Blöcke → prompt-v5 → methodik-v6 → faq-chat-v7 → perspectives-v3 → unbond-preserve-v2 → hero-program-v1 → unbond-unified → unbond-focus → unbond-below-hero → unbond-final-cta → unbond-nothing-buttons → unbond-painpoints → unbond-bereich → unbond-index-fonts → unbond-index-typo (20 Dateien + 9 Inline-Blöcke) |

---

## A · Custom Properties

### A1 · Welt 1 Nothing · Kern (`unbond-nothing.css`, `:root`)

| Token | Wert | Rolle |
|---|---|---|
| `--nt-black` | `#000` | Seitengrund |
| `--nt-surface` | `#0d0d0d` | Kacheln, Karten |
| `--nt-line` | `#343434` | Rahmen |
| `--nt-line-soft` | `#222` | Trennlinien, Balkengrund |
| `--nt-text` | `#e8e8e8` | Text |
| `--nt-text2` | `#a3a3a3` | Sekundärtext, Labels |
| `--nt-text3` | `#8a8a8a` | Tertiär (Meta, Copyright) |
| `--nt-red` | `#7d263f` | Bordeaux, Knöpfe |
| `--nt-red-hover` | `#96334f` | Hover, Bullet-Zeichen |
| `--nt-gold` | `#d2a63b` | nur Zahlen |
| `--nt-sans` | `"Space Grotesk", system-ui, …` → überschrieben zu `"Poppins", system-ui, "Segoe UI", Roboto, Arial, sans-serif` (unbond-nothing-poppins.css) | |
| `--nt-mono` | `"Space Mono", ui-monospace, …` → überschrieben zu **Poppins** (gleiche Datei) | |
| `--nt-w` | `1120px` | Inhaltsbreite |
| `--nt-nav-h` | `72px` | Kopfzeilenhöhe |

### A2 · Welt 1 · Bereichs-Tokens (`unbond-bereich.css`, auf `body[data-bereich]`)
`--ub-c` (Leitfarbe), `--ub-sig` (Signalfarbe), `--ub-sig-soft` (= `color-mix(in srgb, var(--ub-c) 18%, transparent)`). Werte siehe Abschnitt B.

### A3 · Welt 1 · Komponenten-lokale Tokens

| Token | Wert | Datei |
|---|---|---|
| `--ub-weiter-line` | `#343434` | unbond-weiter.css (`.ub-weiter`) |
| `--ub-weiter-surface` | `#0d0d0d` | unbond-weiter.css |
| `--c` | pro Karte per JS (`unbond-weiter.js`): toxikometer/report `#bc5470`, narzissmus `#9b7fa4`, bindung `#c4836e`, kompass `#5e9590`, spielautomat `#6fb0a8`, nocontact `#7a9e8a`, buch `#d2a63b` | unbond-weiter.js |
| `--icon` | `url(assets/icons/sm/<name>)` per JS | unbond-weiter.js |
| `--gold` | `#d2a63b` (`.ub-buch`) | unbond-weiter.css |
| `--tile-img` | Bild-URL pro Kachel (inline style) | wissen/klarheit/tools/phase-2 |
| `--w-tl-p`, `--w-tl-y` | Scrollfortschritt 0…1 / px, per JS | unbond-weg-tl.js |
| `--tze-*` (37 Tokens) | siehe A4 | leseprobe-wolf-im-schafskittel.html |

### A4 · Leseprobe-Tokens (`--tze-*`, Inline in leseprobe-wolf-im-schafskittel.html, `:root`)

| Gruppe | Werte |
|---|---|
| Abstand | `--tze-space-1…7`: `.25rem .5rem .75rem 1rem 1.5rem 2rem 3rem` |
| Radius | `--tze-radius-s/m/l`: alle `4px` |
| Größe | `--tze-size-xs .8125rem · s .9375rem · m 1.0625rem · l 1.375rem · xl 1.875rem` |
| Zeilen | `--tze-line-tight 1.25 · --tze-line-body 1.65` |
| Bewegung | `--tze-speed 220ms · --tze-ease cubic-bezier(.4,0,.2,1)` |
| Farbe | `--tze-bg #000 · --tze-surface #0d0d0d · --tze-surface-alt #161616 · --tze-border #343434 · --tze-text #e8e8e8 · --tze-text-muted #a3a3a3 · --tze-text-invert #000 · --tze-accent var(--ub-c,#B4869F) · --tze-accent-soft rgba(180,134,159,.16) · --tze-accent-2 var(--ub-c,#B4869F) · --tze-accent-3 #5e9590 · --tze-signal #7d263f · --tze-focus #e8e8e8` |
| Sonst | `--tze-touch 44px · --tze-shadow none · --tze-glass-blur 0px · --tze-measure 100% · --tze-font-body "Poppins",system-ui,"Segoe UI",sans-serif · --tze-font-head var(--tze-font-body)` |

### A5 · Welt 1 · Übersetzungsschichten (Altvariablen auf Nothing-Werte gebogen)

**unbond-nothing-skin.css** (`html body.nt-skin`): `--background #000 · --foreground #e8e8e8 · --card #0d0d0d · --muted #0d0d0d · --muted-foreground #a3a3a3 · --border #343434 · --accent #7d263f · --accent-hover #96334f · --accent2 #7d263f · --gold #d2a63b · --gold-l #e8e8e8 · --green #a3a3a3 · --radius 8px · --bg #000 · --fg #e8e8e8 · --fg-m #a3a3a3 · --r 8px · --void #000 · --deep #0d0d0d · --card-hover #0d0d0d · --cream #e8e8e8 · --fog #e8e8e8 · --ash #a3a3a3 · --teal #7d263f · --wine #a3a3a3 · --font/--font-body/--font-heading/--font-display var(--nt-sans) · --unbond-bg #000 · --unbond-text #e8e8e8 · --unbond-muted #a3a3a3 · --unbond-card #0d0d0d · --unbond-border #343434 · --unbond-burgundy #7d263f · --unbond-burgundy-hover #96334f · --unbond-trust-h/--unbond-nav-h/--unbond-shell-offset/--trust-h 0px`

**unbond-nothing-alt.css** (`html:root`, No Contact, Datenschutz, Impressum, Kompass, Spielautomat): `--bg #000 · --card #0d0d0d · --fg #e8e8e8 · --fg-m #a3a3a3 · --border #343434 · --green/--sage #5e9590 · --accent #7d263f · --accent-h #96334f · --glass #0d0d0d · --glass-border #343434 · --color-bg/--color-bg-alt #000 · --color-card/--color-card-glass/--color-muted-bg #0d0d0d · --color-fg/--color-fg-warm #e8e8e8 · --color-fg-muted/--color-fg-subtle #a3a3a3 · --color-border/-gold/-green #343434 · --color-accent #7d263f · --color-accent-hover #96334f · --color-accent-muted #7d263f · --cta-gradient none · --color-gold #d2a63b · --color-gold-light #e8e8e8 · --color-gold-faint transparent · --color-green #5e9590 · --color-warm #a3a3a3 · --cta-bg #7d263f · --cta-bg-hover #96334f · --font-display/--font-heading/--font-body 'Poppins',system-ui,sans-serif · --shadow-md none · --shadow-glow-accent none`

**Darunter liegende Altwerte** (werden überschrieben, bleiben aber im Code): style.css `--background #131926 · --foreground #f7f2ea · --card #1b2230 · --border #323a49 · --accent #6f2035 · --accent-hover #862840 · --gold #d2a63b · --green #7a9e8a · --warm #c4836e · --muted-foreground #929aaa · --radius 8px · --fs-body 17/18px · --fs-small 13px · --fs-section clamp(28px,3.5vw,32px) · --ease-soft cubic-bezier(.22,.61,.36,1)`; unbond-shell.css `--unbond-bg #131926 · --unbond-bg-deep #0d1119 · --unbond-card #1b2230 · --unbond-border #323a49 · --unbond-text #f7f2ea · --unbond-muted #929aaa · --unbond-burgundy #6f2035 / -hover #862840 · --unbond-gold #d2a63b · --unbond-gold-light #e7c596 · --unbond-sage #7a9e8a · --unbond-warm #c4836e · --unbond-radius 10px · --unbond-nav-h 70/78px · --unbond-trust-h 38/56px · --font-body Lato · --font-heading Poppins · --font-display Playfair`; Inline in narzissmus-/bindungsmuster-test (`--bg #131926 … --r 14px --max 1100px --mauve #9B7FA4`), blog/index (`--void #10181d --card #1e2a2e --teal #6fb0a8 --merlot #6e1728 --wine #8f1f36 …`), no-contact/index (`--color-bg #131926 --color-accent #6f2035 --color-gold #85ab91 …`).

**tools.css** (Spielautomat, `:root`): `--bg #131926 · --card #1b2230 · --fg #edebe6 · --fg-m #a4abb8 · --border #323a49 · --green/--sage #85ab91 · --accent #6f2035 · --accent-h #832640 · --mauve #9b7fa4 · --gold #d2a63b · --terracotta #c46a52 · --glass rgba(11,16,26,.82) · --glass-border rgba(133,171,145,.22) · --font 'Lato',Arial,sans-serif` (durch nothing-alt.css teilweise überschrieben, weil `html:root` spezifischer ist).

**blick-ins-buch.html** (2 Inline-`:root`): Block 1 `--bg #0a0d14 · --bg-2 #0f1420 · --bg-3 #151b29 · --card rgba(20,26,40,.72) · --glass rgba(15,20,34,.62) · --line rgba(247,242,234,.12) · --line-gold rgba(210,166,59,.4) · --cream #f7f2ea · --text #e4e1dc · --muted #9aa2b1 · --gold #d2a63b · --gold-l #e7c596 · --bordeaux #6f2035 · --bordeaux-h #862840 · --sage #7a9e8a · --mauve #9b7fa4 · --terra #c4836e · --head Poppins · --body Lato · --serif Playfair · --r 10px · --ease cubic-bezier(.22,.61,.36,1)`; Block 2 (Zeile 286) `--bg #0b1019 · --text #edebe6 · --muted #bec4ce · --sage #85ab91 · --bordeaux #7d263f · --bordeaux-h #96334f · --gold #d2a63b · --head "Space Grotesk" · --mono "Space Mono" · --serif "Instrument Serif" · --yellow #e8c547 · --line-gold rgba(210,166,59,.38) · --line rgba(180,190,205,.2)` [welcher Block wo gilt: unbekannt, beide auf `:root`].

### A6 · Welt 2 Stitch (`tools/phase-2/klarheitscheck/app.css`, `:root`)

| Token | Wert | | Token | Wert |
|---|---|---|---|---|
| `--bg` | `#0f141b` | | `--mint` | `#3fd3a2` (Knopf) |
| `--deep` | `#000` (Kopfzeile) | | `--primary` | `#62f0bd` (Akzent, Fokus) |
| `--surface` | `#0e131a` (Karte) | | `--pink` | `#ffb1c0` |
| `--elevated` | `#171e28` | | `--crimson` | `#7d263f` |
| `--sc` / `--sc-low` / `--sc-high` | `#1b2027` / `#171c23` / `#252a32` | | `--error` | `#ffb4ab` |
| `--text` | `#dee2ed` | | `--outline` | `#86948c` |
| `--text-var` | `#bbcac1` | | `--line` | `#3c4a43` |
| `--hair` / `--hair2` | `rgba(255,255,255,.1)` / `.05` | | `--head` / `--body` / `--mono` | Space Grotesk / Plus Jakarta Sans / Space Mono |

### A7 · Welt 3 Startseite (Auswahl, alle Dateien mit `:root`)

| Datei | Tokens (Wert) |
|---|---|
| site-v21.css | `--bg #0b1019 · --text #edebe6 · --muted #bec4ce · --gold #d2a63b · --sage #85ab91 · --bordeaux #6f2035 · --bordeaux-hover #872942 · --focus #f0c65d · --card rgba(17,24,36,.9) · --card-strong rgba(14,20,31,.96) · --border rgba(180,190,205,.2) · --radius 16px · --shadow 0 24px 70px rgba(0,0,0,.36) · --page 1160px · --block 940px · --type-body 1.0625rem · --type-small .78rem · --type-display clamp(2.18rem,5.1vw,4.75rem) / mobil clamp(2.05rem,10.2vw,3.1rem)` |
| redesign-v32.css | `--page 1160px · --type-body clamp(1.0625rem,1rem+.3vw,1.125rem) · --type-display clamp(2.3rem,1.52rem+2.55vw,3.9rem) · --type-h2 clamp(1.9rem,1.32rem+2.05vw,3.15rem) · --type-small .875/.9375rem · --quote-gap 12/16px · --quote-width …` |
| glass-v33.css | `--g-fg #ecebe6 · --g-muted #b9c1c0 · --g-soft #98a3a4 · --g-sage #a9c9b3 · --g-yellow #e0b75a · --g-mauve #c79ab7 · --g-bordeaux #7b233c · --g-glass #121923 · --g-glass-strong rgba(16,22,34,.74) · --g-glass-light rgba(255,255,255,.055) · --g-line rgba(226,232,228,.13) · --g-line-hi rgba(255,255,255,.22) · --g-gold-line rgba(224,183,90,.38) · --g-radius 22px · --g-blur blur(10px) · --g-shadow none · --g-gold var(--g-sage)` |
| reference-type.css | `--type-body 1rem · --type-small .82rem · --type-h2 clamp(1.4rem,3vw,2rem) · --type-display calc(clamp(2.2rem,5.6vw,4rem) - 2px)` |
| ux-refinement.css | `--g-fg #f4f3ee · --g-muted #ced5d0 · --g-soft #b4c0ba · --g-sage #b6d7c0 · --g-gold #e6c37b · --ux-line rgba(234,239,234,.18) · --ux-line-active rgba(230,195,123,.58) · --ux-focus #ffe0a1 · --ux-page 1180px · --ux-reading 68ch · --ux-surface rgba(15,22,33,.86) · --ux-surface-raised rgba(20,28,41,.92)` |
| prompt-v5.css | `--unbond-teal #159A82 · --unbond-teal-line rgba(21,154,130,.55) · --unbond-teal-subtle rgba(21,154,130,.13) · --unbond-number-gold #D2A63B · --unbond-night #0D111A` (+ biegt `--gold`, `--g-gold`, `--g-yellow`, `--focus` auf Teal) |
| perspectives-v3.css | `--perspective-bg #0c121a · --perspective-surface #111a23 · --perspective-surface-soft #141e28 · --perspective-text #f1f3f0 · --perspective-muted #b8c0c6 · --perspective-line rgba(21,154,130,.72) · --perspective-line-soft rgba(233,233,228,.18) · --perspective-number var(--unbond-number-gold,#d2a63b)` |
| unbond-focus.css / unbond-below-hero.css | `--uf-/--bh-bord #7d263f · gold #d2a63b · line rgba(226,232,228,.16) · panel rgba(8,13,20,.88/.86) · --bh-teal #159a82` |
| unbond-painpoints.css | `--pf-gold #bc8e3b · --pf-sage #5e9590 · --pf-cream #f4f1ea · --pf-ink #0b0d17 · --pf-glass rgba(15,20,35,.55) · --pf-gold-line rgba(188,142,59,.20) · --pf-sage-line rgba(94,149,144,.20) · --pf-subtle rgba(244,241,234,.74) · --pf-card-h 430px · --pf-art-scale .75` |
| unbond-unified.css | `--page 1160px · --unified-veil rgba(7,10,17,.66)` |
| unbond-nothing-buttons.css | `--nb-red #7d263f · --nb-red-hover #96334f · --nb-text #e8e8e8 · --nb-gold #d2a63b · --nb-arrow #d9879d`; in `.understand-tile`: `--ut-green #5e9590 · --ut-green-hover #4a7a75 · --ut-green-light #9cc7c1` |
| index.html Inline | `--nothing-bordeaux #7d263f · --nothing-bordeaux-hover #96334f · --nothing-line #343434 · --nothing-text #e8e8e8 · --nothing-muted #a3a3a3 · --hybrid-ink #243443 · --hybrid-paper #f7f3ec · --hybrid-paper-strong #fffdf9 · --hybrid-sage #dfe9dc · --hybrid-mauve #b4869f · --hybrid-muted #647382 · --type-h2 …` |
| unbond-index-typo.css (zuletzt geladen, gewinnt) | `--ub-fs-h1 clamp(2.4rem,5.2vw,3.8rem) · --ub-fs-h2 clamp(1.7rem,3vw,2.1rem) · --ub-fs-text 1rem · --ub-fs-small .8125rem` |
| unbond-bereich.css (Start-Override, `body[data-bereich="start"]`) | `--sage, --g-sage, --unbond-teal, --bh-teal, --pf-sage = #b6d7c0 · --unbond-teal-line rgba(182,215,192,.55) · --unbond-teal-subtle rgba(182,215,192,.13) · --pf-sage-line rgba(182,215,192,.20) · --ut-green* #b6d7c0, --ut-green-hover #4f6b5a` → alle Grün/Türkis-Töne der Startseite werden **#b6d7c0** |

---

## B · Bereichsfarben (`unbond-bereich.css`)

| data-bereich | `--ub-c` | `--ub-sig` | `--ub-sig-soft` | Bedeutung laut Kommentar |
|---|---|---|---|---|
| `start` | `#d2a63b` | nicht gesetzt (eigener Block: alle Grüntöne → `#b6d7c0`) | – | Startseite |
| `wissen` | `#d2a63b` | `#7a9e8a` (Override 06.11.) | `rgba(122,158,138,.18)` | Übersicht |
| `klarheit` | `#B4869F` | = `--ub-c` | color-mix 18 % | 01 Erkennen |
| `nocontact` | `#C97B63` | = `--ub-c` | color-mix 18 % | 02 Abstand halten |
| `blog` | `#E8DCC4` | = `--ub-c` | color-mix 18 % | 03 Verstehen |
| `tools` | `#62f0bd` | = `--ub-c` | color-mix 18 % | 04 Weitergehen |

**Wo `--ub-c` wirkt:** Linie unter Kopfzeile (`box-shadow: inset 0 -2px 0`), aktiver Menüpunkt (Unterstreichung 2px, Offset 9px; mobil `inset 3px 0 0`), Eyebrow über H1, `.ub-weg` aktiver Schritt, Zurück-Knopf Hover/Fokus, Leseprobe-Akzent.
**Wo `--ub-sig` wirkt:** `h1 em`, Bullets (`.nt-tags`, `.trust-row`, Artikel-Listen), Fortschrittsbalken, Ladekreis, Rahmen von `.w-stage-proof`, `.cta-box`, `.opt-btn`, `.q-text`, Spielautomat-Panels. Zahlen bleiben `#d2a63b`, Knöpfe bleiben Bordeaux.

| Seite | data-bereich |
|---|---|
| index.html | `start` |
| wissen.html | `wissen` |
| klarheit.html, toxikometer.html, report.html, narzissmus-test.html, bindungsmuster-test.html, heilungskompass.html, leseprobe-wolf-im-schafskittel.html, tools/spielautomat.html | `klarheit` |
| blog/index.html + 11 Artikel | `blog` |
| no-contact/index.html | `nocontact` |
| tools/index.html, tools/phase-1…6/index.html | `tools` |
| **ohne:** blick-ins-buch.html, datenschutz.html, impressum.html, tools/phase-2/klarheitscheck/index.html | – (Zurück-Hover fällt auf `#96334f` zurück) |

---

## C · Typografie

### C1 · Welt 1 Nothing

**Erzwungene Schrift:** `unbond-nothing-poppins.css` setzt `html body.nt, html body.nt *:not(svg):not(svg *) { font-family: var(--nt-sans) !important }` = **Poppins für alles** auf `body.nt`. Space Grotesk und Space Mono (in unbond-nothing.css deklariert) sind dadurch wirkungslos. Ausnahmen nur mit `!important` **und** höherer Spezifität als (0,1,4): Leseprobe `.lp-hero h1 em` und `.lp-kern` (Playfair Italic). Nicht durchgesetzt (per Spezifität berechnet): `.w-num` (Playfair, ohne !important) und `.tze-szenario__zitat` (Playfair !important, nur 0,1,0) → beide rendern Poppins.

| Familie | geladen aus | Gewichte | Wirkt? |
|---|---|---|---|
| Poppins | `fonts/poppins-v24-latin-{300,regular,500,600,700}.woff2` (unbond-nothing-poppins.css) | 300, 400, 500, 600, 700 | ja, überall |
| Space Grotesk | `fonts/SpaceGrotesk-Regular.ttf`, `-Medium.ttf` (unbond-nothing.css) | 400, 500 | nein (überschrieben) |
| Space Mono | `fonts/SpaceMono-Regular.ttf`, `-Bold.ttf` | 400, 700 | nein (überschrieben) |
| Playfair Display | `fonts/playfair-display-v40-latin.woff2` 700 normal (wissen, unbond-weg-tl.css, tools/phase-2) · `fonts/playfair-display-latin-wght-italic.woff2` 400 italic (Leseprobe) · `playfair-display-v40-latin-ext.woff2` italic 400–700 (Tests, Kompass, Klarheit inline) | s. links | nur Leseprobe-H1-Unterzeile und Kernsatz |
| Lato | `fonts/lato-v25-latin-{300,regular,italic,700}.woff2` (Inline in Tests, Kompass) | 300/400/400i/700 | nein auf `body.nt` |
| Spielautomat (kein `.nt`) | tools.css: Lato 400/700, Poppins `poppins-latin-{300,700,800}-normal.woff2`, Playfair 400–900 | | Lato Fließtext, Poppins Labels, Playfair H1 |

| Rolle | Selektor | Größe | Gewicht | Zeilenhöhe | Spacing | Farbe | Datei |
|---|---|---|---|---|---|---|---|
| Body | `body.nt` | 17px | 400 | 1.6 | – | `#e8e8e8` | unbond-nothing.css |
| H1 Hero | `.nt-hero h1` (auch `.tests-hero .hero-title`, `h1.tox-h2`, Blog-Hero) | clamp(2.3rem, 6.4vw, 4.4rem) | 400 | 1.04 | -.015em | `#e8e8e8`, max 16ch | nothing / skin |
| H1 Unterzeile | `.nt-hero h1 em` | erbt | erbt | – | – | `--ub-sig` (wissen: `#7a9e8a`, italic) | bereich / wissen inline |
| H1 Artikel | `.article-header h1` | clamp(1.9rem, 4.6vw, 3rem) | 400 | 1.1 | -.015em | | skin |
| H1 Report | `.report-hero h1` | clamp(2.1rem, 5.6vw, 3.6rem) | 400 | 1.06 | | | skin |
| H1 Leseprobe | `.lp-hero h1` | clamp(2.1rem, 5vw, 3.4rem) | **600** | 1.08 | **-.025em** | | Leseprobe inline |
| H2 Kachel | `.nt-tile h2`, `.w-tl .nt-tile h2/h3` | clamp(1.5rem, 2.6vw, 2rem) | 500 | 1.15 | normal | `#e8e8e8` | nothing / weg-tl |
| H2 Stage | `.w-stage-t` | clamp(1.6rem, 2.8vw, 2.25rem) | 500 | 1.15 | | | weg-tl / wissen |
| H2 Artikel | `.article-body h2` | clamp(1.35rem, 2.6vw, 1.7rem) | 500 | [unbekannt] | | | skin |
| H2 Report-Karte | `.report-card h2` | clamp(1.45rem, 3vw, 1.9rem) | 400 | 1.2 | | | skin |
| H2 Weiter/Buch | `.ub-weiter-head h2` / `.ub-buch h2` | clamp(1.6rem,1.2rem+1.6vw,2.25rem) / clamp(1.6rem,1.15rem+1.8vw,2.3rem) | erbt / **600** | 1.15 | **-.025em** | `#e8e8e8` / `#fff` | weiter |
| H3 | `.ub-weiter-card h3` 1.25rem/600/-.015em · `.report-card h3` 1.05rem/500 · `.nt-phase h2` 1.15rem/500 | | | | | | |
| Lead | `.nt-lead` | 1.05rem | 400 | 1.6 | – | `#a3a3a3`, max 58ch | nothing |
| Eyebrow / Label | `.nt-label` (+ `.eyebrow`, `.tag`, `.hero-eyebrow` … im Skin) | .72rem | 700 | – | .14em, uppercase | `#a3a3a3`; erste Zeile im Hero = `--ub-c` | nothing / skin |
| Kachel-Kopf | `.nt-tile-top` | .72rem | 700 | | .1em, uppercase | `#8a8a8a`, `.nt-flag` `#e8e8e8` | nothing |
| Tags | `.nt-tags` | .7rem (Stage: .8rem) | | | .06em, uppercase | `#a3a3a3`, Bullet „› “ `#96334f` / `--ub-sig` | nothing |
| Klein / Meta | `.nt-copy`, `.nt-book-meta`, `.article-meta` | .7–.72rem | | | .05–.06em uppercase | `#8a8a8a` | nothing / skin |
| Hinweis | `.nt-note` | .72rem | | | .04em | `#8a8a8a`, max 62ch | nothing |
| Footer-Titel | `.ub-footer-title` | .75rem | 700 | | .14em uppercase | `#d2a63b` | footer |
| Nav | `.desktop-nav a` / mobil | .72rem / .78rem | 700 | | .07em uppercase | `#a3a3a3` → `#fff` | nothing |
| Knopf | `.nt-btn` | .78rem (lg .84rem) | 700 | 1.25 | .065em uppercase | `#e8e8e8` | nothing |
| Zahl (Phasen) | `.w-num` | clamp(34px, 4.4vw, 52px) | 700 | 1 | 0 | `#d2a63b` (Schrift: Poppins, s. o.) | weg-tl / wissen |
| Zahl (Score) | `.radar-score-num`, `.score-n` | clamp(2.6rem, 6vw, 3.4rem) | 700 | 1 | | `#d2a63b` | skin |
| Kernsatz | `.lp-kern` | clamp(1.4rem, 3vw, 1.9rem) | 400 italic | 1.35 | | `#e7c596`, Playfair | Leseprobe inline |
| Zitat Szenario | `.tze-szenario__zitat` | 1.25rem | italic | 1.4 | | `#e7c596` | Leseprobe inline |
| Skin-Regel | `[style*="#e7c596"]` → `#e8e8e8`; `h1 em`, `h2 em` → normal, nicht kursiv | | | | | | skin |

### C2 · Welt 2 Stitch (`app.css`)

| Familie | Datei | Gewichte |
|---|---|---|
| Space Grotesk (Überschriften) | `assets/space-grotesk-latin-{500,600,700}-normal.woff2` | 500, 600, 700 |
| Plus Jakarta Sans (Text) | `assets/plus-jakarta-sans-latin-{400,500,600}-normal.woff2` | 400, 500, 600 |
| Space Mono (Labels, Knöpfe) | `assets/space-mono-latin-{400,700}-normal.woff2` | 400, 700 |

| Rolle | Klasse | Wert |
|---|---|---|
| Body | `body` | 400 16px/24px Plus Jakarta Sans, `#dee2ed` |
| H groß | `.h-md` | 600 32px/40px Space Grotesk, -.02em, `#fff` |
| H klein | `.h-sm` | 600 24px/32px, -.01em |
| Caps-Label | `.caps` | Space Mono 12px/16px, 700, .08em, uppercase |
| Mono klein | `.mono-sm` | Space Mono 11px/14px, .04em |
| Text klein | `.t-sm` | 14px/20px |
| Zitat | `.quote` | 500 18px/1.45 Space Grotesk, `#fff`, Linie links 2px `#62f0bd` |
| Knopf | `.btn` | Space Mono 12px, 700, .08em, uppercase |

### C3 · Welt 3 Startseite

**Erzwungen von `unbond-index-typo.css`** (mit 5–7 `:not(#u…)` → schlägt alles davor): `body` = Poppins 1rem (16px); **jedes Element** `font-family: inherit !important; font-size: inherit !important`. Danach Ausnahmen:

| Rolle | Wert |
|---|---|
| H1 | Poppins, `--ub-fs-h1` clamp(2.4rem, 5.2vw, 3.8rem) |
| H2 | Poppins, `--ub-fs-h2` clamp(1.7rem, 3vw, 2.1rem) |
| Fließtext | Poppins 1rem |
| Klein (Labels, Knöpfe, Footer, Cookie, Quellen) | `--ub-fs-small` .8125rem (13px) |
| Preis/Kennzahlen (`.pf-stat-num`, `.phase-num strong`, `.ed-stats strong`, `.ed-price strong`) | h2-Größe, line-height 1.1 |
| Space Mono | `.header-beacon-cta`, `a.button`, `.hero-scroll-link`, `.at-fig figcaption`, `.pf-kicker`, `.phase-word/-meta/-cue-text/-plus`, `.ed-top span`, `.eb-badge`, `.ed-stats`, `.ed-price strong`, `.ed-once`, `.price-secondary`, `.faq-number`, `.faq-kicker`, `.checkout-note`, `.footer-link`, `.cookie-button` |
| Playfair Display Italic | `.at-fig p`, `.pf-sub`, `.phase-pain` (Zitate) |

Schriftdateien (`unbond-index-fonts.css`): Poppins 300–800 `fonts/poppins-v24-latin-*.woff2` + 900 `fonts/poppins-latin-900-normal.woff2`; Space Grotesk 300–700 `fonts/SpaceGrotesk-*.ttf`; Space Mono 400/700 `.ttf`; „Instrument Serif“ = Alias auf `playfair-display-latin-wght-italic.woff2` / `playfair-display-v40-latin.woff2`; Playfair Display Italic 400–900; „Instrument Sans“ = Alias auf Lato 400/700.

---

## D · Abstand, Radius, Linie, Schatten, Bewegung

### D1 · Welt 1

| Kategorie | Wert | Quelle |
|---|---|---|
| Inhaltsbreite | `width: min(100% - 48px, 1120px)`; ≤640px `100% - 32px` (Gutter 24 / 16px) | `.nt-wrap`, `.container`, `.ub-weg-inner`, `.ub-zurueck` |
| Lesebreiten | Artikel 980px, Report 980px, Weiter/Buch 960px, Leseprobe 720px, Zwei-Schritt-Weiter 720px | skin / weiter / Leseprobe |
| Kopfzeile | 72px (≤640px 64px); Trust-Leiste min 38px; Wegweiser min 48px | nothing / bereich |
| Hero-Padding | oben clamp(56px, 10vw, 112px), unten clamp(40px, 6vw, 72px) | `.nt-hero` |
| Großabstände | Buch clamp(64px,9vw,112px) · Footer-Abstand clamp(48px,8vw,96px) · Weiter clamp(40px,7vw,72px) · Stage-Abstand 72px (mobil 48px) · Stage-Spalten-Lücke 120px | |
| Kachel | Padding 24px, Gap 14px, min-height 340px (Stage 380px, kompakt 300px), Raster-Gap 16px | `.nt-tile` |
| Karte Report | Padding clamp(20px, 3.4vw, 32px), Abstand 20px | skin |
| Radius | **4px** Knöpfe, Chips, Badges, Eingaben · **8px** Kacheln, Karten · **50%** Logo-Kreis, Punkte · Ausreißer: 14px Weiter-Karte/-Icon, 16px Buch-Block, 18px Buch-Icon, 12px Quellen, 10px Quellen-Icon, 8px Buch-Knopf, 0 Fortschrittsbalken, `0 8px 8px 0` Hinweiskästen | |
| Linien | 1px `#343434` Standard · 1px `#222` weich · 2px links `#7d263f` (Hervorhebungskästen), 2px links `#a3a3a3` / `#e8e8e8` (Report-Hinweise) · 2px oben `#d2a63b` (Buch) · dashed für gesperrt | |
| Schatten | keine (Skin setzt überall `box-shadow: none`). Ausnahmen: Zeitstrahl-Punkt `0 0 0 6px rgba(232,232,232,.1)`, Weiter-Nummer `0 0 0 6px #000` (Maske) | |
| Fokus | `outline: 2px solid #fff; outline-offset: 4px` (Zurück: `--ub-c`, Offset 2px; Weiter-Karte: `--c`, Offset 3px; Leseprobe 3px `#e8e8e8`) | |
| Dauer/Kurven | `.18s ease` (Knöpfe, Kacheln, Nav) · `.2s ease` (Footer, Buch-Knopf) · `.25s ease` (Weiter-Karte, Kachelbild) · `.7s ease` + `.7s cubic-bezier(.16,1,.3,1)` (Zeitstrahl-Einblendung) · `.24s ease-out` (`report-rise`) · 220ms `cubic-bezier(.4,0,.2,1)` (Leseprobe) | |
| Bewegungen | Kachelbild Deckkraft .36 → .52 · Weiter-Karte `translateY(-3px)`, Pfeil `translateX(4px)` · Zeitstrahl Einblendung ±28px X (mobil 20px Y) · Zyklus-Knoten `scale(.98)` aktiv | |
| Reduced Motion | nothing.css: `body.nt * { transition: none !important }` · skin: zusätzlich `animation: none` · Hintergrundvideo ausgeblendet · weg-tl: alles sofort sichtbar, Punkt aus, JS setzt `--w-tl-p: 1` · weiter/zurück/buch: keine Transition/Transform · Leseprobe: 1ms | |
| Druck | Trust, Topnav, Footer, Wegweiser, Zurück ausgeblendet; Report weiß mit `#bbb`-Rahmen | |

### D2 · Welt 2 Stitch
Bereich `main` max 42rem, Padding 80px 16px 96px (≥640px seitlich 24px) · Kopfzeile 56px fest · Stapelabstand 24px · Karte Padding 24px, Radius 12px · Radien 12 / 8 / 6 / 4 / 3 / 999px · Modal-Schatten `0 25px 50px -12px rgba(0,0,0,.6)` · Fokus 2px `#62f0bd` Offset 2px · Bewegung `.15s` (Knopf, Chips), `.1s` scale(.98), `.3s` Fortschritt, `.view` fade `.3s` translateY(6px) · Reduced Motion: `.view` und Balken ohne Animation.

### D3 · Welt 3 Startseite
Seitenbreite 1160px (site, redesign, unified) bzw. 1180px (`--ux-page`, Kopfzeile) · Kopfzeile min 80px (mobil 68px) · Radien 4px (Knöpfe nach nothing-buttons), 8px (Phasen, ed-card, rc-card), 16px (site), 18px (Blick-ins-Buch-Kasten), 22px (`--g-radius`) · Schatten `--shadow 0 24px 70px rgba(0,0,0,.36)` (site), sonst meist `none` · Knopf-Transition `.18s cubic-bezier(.25,.1,.25,1)` · Fokus Knöpfe `3px solid var(--unbond-teal)` → auf Start `#b6d7c0`, Offset 4px; Kopfzeilen-CTA 2px `#fff` · Reduced Motion: nothing-buttons schaltet Transitions aus; übrige Dateien [unbekannt].

---

## E · Komponenten

### E1 · Welt 1 Nothing

| Komponente | Klassen | Zweck | Varianten / Zustände | Schlüsselwerte | Beispiel |
|---|---|---|---|---|---|
| Krisenleiste | `.nt-trust`, `.nt-trust-inner`, `.nt-sep`, `.nt-hide-s` | Hinweis „Kein Ersatz für Therapie“ + Hotlines | Link-Hover unterstrichen; `.nt-hide-s` ≤640px aus | bg `#000`, Linie unten `#222`, .7rem (mobil .66rem) uppercase .05em, Links 700 `#e8e8e8`, min 38px | wissen.html |
| Kopfzeile | `.topnav`, `.nav-inner`, `.brand`, `img.ub-wortmarke`, `.desktop-nav`, `a.cta` | Logo, Hauptmenü, Buch-CTA | `aria-current="page"` → `#fff` + Bereichs-Unterstreichung; sticky; Punktraster rechts (`radial-gradient #333 1px`, 16px, .55) | bg `#000`, Linie `#343434` + inset 2px `--ub-c`, Wortmarke 64px hoch (≤760px 48px), Links min 44px | alle Unterseiten |
| Mobilmenü | `.menu-btn`, `.mobile-panel(.show)` | ≤1020px | `.show` = grid; Hover-Rahmen `#7d263f` | Knopf 48×48, Radius 4px; Einträge min 52px, Linie `#222`; aktiver Punkt inset 3px `--ub-c` | alle |
| Wegweiser | `.ub-weg`, `.ub-weg-inner`, `.ub-weg-label`, `ol`, `.ub-n`, `.ub-t`; Variante `.ub-weg--tests` mit `.ub-weg-tests`, `.ub-weg-tn`, `.ub-weg-tt` | „Dein Weg“ 01–04 + Testleiste | `aria-current="step"` (weiß, 2px Unterkante `--ub-c`), Tests `aria-current="page"` (gefüllter Kreis `--c`); mobil nur Nummern | bg `#050505`, Linie `#222`, min 48px, Links .8rem/500 `#8a8a8a`, Pfeil „→“ `#3d3d3d` | klarheit.html |
| Testleiste (alt) | `.ub-ktests…` | fünf Selbsttests | wie Wegweiser | Kreis 24px | [ersetzt laut Kommentar, Nutzung unbekannt] |
| Hero | `.nt-hero` > `.nt-label` + `h1` (+`em`) + `.nt-lead` | Seitenkopf | erste `.nt-label` in `--ub-c` | s. C1 | wissen.html |
| Kachel | `.nt-tiles` (`--4` = 2 Spalten), `.nt-tile`, `.nt-tile-top`, `.nt-flag`, `.nt-tags`, `.nt-tile-go`, `.nt-tile-state` | Einstieg in Bereiche | `--lead` (Rahmen `#7d263f`, Spalte 1.5fr), `--img` (Gefühlsbild rechts unten, Deckkraft .36/.52, gesperrt .26), `--locked` (gestrichelt, Text `#a3a3a3`, kein Hover), Hover Rahmen `#96334f`, `.nt-tile-go` füllt sich bei Kachel-Hover | bg `#0d0d0d`, Linie `#343434`, Radius 8px, Padding 24px, min 340px; Flags: „Hier starten“, „Soforthilfe“, „Erste Übung frei“, „Im Aufbau“ | wissen.html, tools/index.html |
| Warteliste | `.wissen-waitlist`, `.wl-row`, `.wl-legal`, `.wl-msg`, `.wl-hp` | E-Mail in gesperrter Kachel | `input:focus` 2px `#96334f`; Knopf `[disabled]` .6 | Input min 44px, Radius 4px, bg `rgba(0,0,0,.55)` | wissen.html |
| Phasen | `.nt-phases`, `.nt-phase` (`--live`), `.nt-phase-num`, `.nt-phase-go` | Tool-Phasen | gesperrt gestrichelt; `--live` durchgezogen `#7d263f` | Padding 20px 24px, Radius 8px, Nummer Gold | tools/index.html |
| Zeitstrahl | `.w-tl` (`--compact`), `.w-tl-track/-fill/-dot`, `.w-stage`, `.w-stage-text`, `.w-stage-t/-s/-proof`, `.w-num`, `.wissen-dots` | Zickzack-Weg | `.js-tl` + `.is-in` Einblendung; ungerade Stufen Kachel rechts; ≤900px einspaltig, Linie links 4px | Linie 1px `#343434`, Füllung `#e8e8e8` per `scaleY(--w-tl-p)`, Punkt 9px; Proof-Linie 2px `#7a9e8a` → `--ub-sig` | wissen.html, klarheit.html |
| Buch (ruhig) | `.nt-book`, `.nt-book-copy`, `.nt-book-meta` | Abschluss wissen | – | Linie oben `#222`, Text 1.1rem | wissen.html |
| Knopf primär | `.nt-btn` (`--lg`), `.topnav a.cta`; im Skin auch `.btn`, `.test-cta`, `.bridge-primary`, `.btn-primary`, `.btn-outline`, `.btn-pdf`, `.intext-cta a`, `.article-cta a`, `.report-btn-primary`, `.k-btn`, `.wl-row button` | Hauptaktion | Hover: bg `#7d263f`, Rahmen `#96334f`, Text `#fff`; `--lg` ≤640px volle Breite | min 48px (lg 54px), Padding 11px 18px (lg 14px 24px), Rahmen 1px `#7d263f`, bg `rgba(125,38,63,.13)`, Radius 4px, uppercase | wissen.html |
| Knopf sekundär/Ghost | `.btn-sec`, `.btn-ghost`, `.ghost`, `.btn-back`, `.btn-pdf-dl`, `.bridge-secondary`, `.btn.secondary`, `.report-btn` | Nebenaktion | Hover Rahmen `#96334f`, Text `#fff`; `:disabled` .35 | min 44px, Padding 10px 16px, Rahmen `#343434`, transparent, Text `#a3a3a3`, .74rem | klarheit.html |
| Knopf voll (Leseprobe) | `.lp-btn`, `.lp-btn--ghost` | CTA Leseprobe | Hover `#96334f`; Ghost-Hover `rgba(125,38,63,.18)` | bg `#7d263f` gefüllt, min 44px, .75rem .08em | leseprobe |
| Buch-Knopf | `.ub-buch-cta` | Kauf-Weg Buch | Hover `#96334f` + `translateY(-1px)`; Fokus 2px Gold | bg `#7d263f` gefüllt, min 54px, Padding 0 30px, **Radius 8px**, .9rem .08em | Report (per JS) |
| Türkis-Kaufknopf | – | – | **nicht vorhanden**: Regelwerk-Türkis `#6FB0A8` kommt auf der Website nur als Weiter-Farbe „Spielautomat“ vor | | |
| Skala/Antworten | `.scale button`, `.score-btn`, `.l-btn`, `.l-n`, `.opt-btn` | Testantworten | Hover Rahmen `#96334f`; `.selected`/`.sel` bg `#7d263f` (l-btn `rgba(125,38,63,.22)`) | Radius 4px, bg `#000` | toxikometer, narzissmus-test |
| Fortschritt | `.progress`, `.progress-track`, `.progress-bar/-fill` | Testfortschritt | – | 4px hoch, Grund `#222`, Füllung `#96334f` → `--ub-sig` | toxikometer |
| Zurück | `.ub-zurueck`, `.ub-zurueck-link` | Zurück am Seitenende | Hover/Fokus Rahmen `--ub-c` (Fallback `#96334f`), Text `#fff`, Outline 2px | min 44px, Padding 10px 18px, Rahmen `#343434`, Radius 4px, Poppins .9375rem/600 | alle außer Startseite |
| Weiter | `nav.ub-weiter`, `.ub-weiter-head`, `.ub-weiter-list` (`--2`, `--1`), `.ub-weiter-card`, `.ub-weiter-icon`, `.ub-weiter-kicker`, `.ub-weiter-points`, `.ub-weiter-go`, `.ub-weiter-more` | nummerierte nächste Schritte | Hover Rahmen `--c`, bg 7 % `--c`, `translateY(-3px)`; Fokus 2px `--c`; aktiv -1px; mobil vertikal mit Linie links | Karte Padding 24px 22px 20px, **Radius 14px**, bg `#0d0d0d`; Nummer 32px Kreis; Icon 60px (Maske 46px) | report.html, Tests |
| Buch-Block | `.ub-buch`, `-icon`, `-kicker`, `-text`, `-points`, `-actions`, `-cta`, `-sample`, `-meta` | Buch-Abschluss | s. Buch-Knopf | Padding clamp(24px,4vw,40px), Radius 16px, Linie oben 2px Gold, Häkchen Gold | Report/Tests (per JS) |
| Quellen | `details.ub-quellen`, `-icon`, `-n`, `-note`; `.ub-hinweis` | Quellen-Klappmenü, Hinweiszeile | `[open]` dreht Chevron | min 56px, Radius 12px, Icon-Maske `icon-klinisch.webp`; Hinweis-Icon `icon-fuersorge.webp` in `#5e9590` | Tests |
| Footer | `footer.ub-footer`, `-inner`, `-brand`, `-by`, `-title`, `-link`, `-bottom` | Marke, „Dein Weg“, Rechtliches, Krisenhinweis | Links Hover `#fff`; Fokus 2px `#fff` | 3 Spalten 1.3fr/1fr/1fr (≤760px 2, ≤420px 1), Gap 32px 48px, Padding 48px 16px 28px, Logo 132px, Unterzeile Linie `#222`, Link-Unterstrich `#7d263f` | alle 32 Unterseiten |
| Footer alt | `.nt-footer…` | – | – | in nothing.css definiert, **auf keiner Seite genutzt** | – |
| Cookie-Banner | `#cookieBanner`, `.cookie-inner`, `.cookie-title/-desc`, `.cookie-categories`, `.cookie-toggle-row`, `.cookie-btns` (`.cookie-accept/-decline/-save`), `#cookieReopen` | Einwilligung | v2: Seite bleibt bedienbar; Accept/Decline gleichwertig; Hover `#832640`; Fokus 3px `#f0c65d` | **Altdesign**: Kasten `rgba(20,27,40,.985)`, Rahmen `#465064`, Radius 12px, Zeilen `#1d2534`/`#323a49` Radius 7px, Knöpfe `#283246`/`#536073` Radius 8px, Accept/Decline `#6f2035`, Checkbox `#85ab91`, Schrift 11–14px Poppins; Titel mit 🍪 | unbond-consent.css, alle Unterseiten |
| Consent-Knopf (Nothing) | `body.nt #cookieReopen`; im Footer `#cookieReopen` als Textlink | Wiederöffnen | – | Radius 4px, Rahmen `#7d263f`, bg `#000` | nothing / footer |
| Hervorhebungskasten | `.abstract-box`, `.highlight-box`, `.intext-cta`, `.quote` | Artikel | – | bg `#000`, Linie `#343434`, links 2px `#7d263f`, Radius `0 8px 8px 0` | Blogartikel |
| Report: Ergebnis-Kopf | `.report-result-grid`, `.report-profile-name`, `.report-score-row`, `.report-score-box`, `.report-tier`, `.report-scale li(.is-on)`, `.report-radar-box`, `.report-cats`, `.report-cat-*` | Score + Profil + Radar | `.is-on` Rahmen `#e8e8e8` | Kästen bg `#000`, Radius 8px, Padding 20px; Balken 2px, Füllung `#e8e8e8`, Werte Gold | report.html |
| Report: Bereiche | `.report-areas-list`, `.report-area` (`--l1/l2/l3`), `-head`, `-level`, `-bar/-fill`, `-what`, `-meaning`, `.report-checklist`, `.report-check`, `.report-check-count` (`.is-wenig/-einige/-viele`) | 5 Bereiche mit Abgleich | Linie links `#8a8a8a`/`#a3a3a3`/`#e8e8e8`; Rückmeldung links `#343434`/`#5e9590`/`#96334f`; Checkbox `accent-color #7d263f` | 2 Spalten (≤900px 1), Padding 20px | report.html |
| Report: Profile | `details.report-profile` (`.is-own`), `.report-profile-icon/-tag`, `details.report-profiles-fold` | 7 Profile | `.is-own` Rahmen `#e8e8e8` | Radius 8px; Tag Radius 4px .64rem | report.html |
| Report: Plan/Warum | `.report-plan`, `.report-plan-week` (Zähler „01…“ Gold), `.report-why`, `.report-why-item` | 30-Tage-Plan, Erklärung | 4/2/1 Spalten | Padding 18px, Radius 8px | report.html |
| Report: Hinweise | `.report-caution/-note/-safety/-takeaway` | Sicherheits- und Merkkästen | Safety: Icon-Maske `icon-fuersorge.webp` `#9b7fa4` | Linie links 2px `#a3a3a3` (`safety` `#e8e8e8`) | report.html |
| Report: Abschluss | `.report-book`, `.report-endbar`, `.report-next-links`, `.report-skip` | Buch, PDF/Neustart | – | Linie oben `#222` | report.html |
| Report: Tabs | – | – | **nicht vorhanden** (keine Tab-Klassen in report.css/report-results.css/skin) | | |
| Report: Kreislauf | `.report-cycle`, `-ring`, `-node` (`aria-selected`), `-num`, `-panel`, `-take`; `.report-check-summary`, `.report-summary-*` | Kreislauf-Ring, Gesamt-Rückmeldung | `aria-selected="true"` Rahmen `#96334f`, bg `rgba(125,38,63,.18)` | Knoten min 92px | **CSS vorhanden, in keiner HTML/JS-Datei verwendet** |
| Narzissmus-Ergebnis | `#screen-result .result-top`, `.typus-name/-tag`, `.score-ring`, `.cat-badge` (`.cat-high/-medium/-low`), `.chart-wrap`, `.dim-tiles`, `.dim-tile-*` | Ergebnisansicht | Badges Linie links `#e8e8e8`/`#a3a3a3` | Raster wie Report, Padding clamp(20px,3.4vw,32px) | narzissmus-test.html |
| Leseprobe `.tze` | `.tze`, `.tze__label/__title/__hint/__skip/__controls`, `.tze--schwer`, `button[aria-pressed]` | Rahmen interaktiver Bausteine | Hover bg `--tze-accent-soft`; `aria-pressed="true"` bg `--tze-accent`, Text `#000`; Fokus 3px `#e8e8e8`; `--schwer` Linie links 3px `#7d263f` | bg `#0d0d0d`, Rahmen `#343434`, Radius 4px, Padding 1.5rem, Knopf min 44px | leseprobe |
| Leseprobe Vergleich | `.tze-vergleich__toggle/__grid/__row/__kopf`, `dd[data-seite="a/b"]` | Gegenüberstellung | mobil Umschalter, ≥640px 3 Spalten 1fr/1.4fr/1.4fr | Seite a `#a3a3a3` kursiv, Kopf `--tze-accent` | leseprobe |
| Leseprobe Szenario | `.tze-szenario__knoten/__folge/__zurueck/__zitat` | Entscheidungsszenario | Zurück .75 Deckkraft | Folge bg `#161616`, Linie links 3px `--tze-accent-2` | leseprobe |
| Leseprobe Glossar | `.tze-glossar`, `__begriff`, `__def` | Begriff aufklappen | `[hidden]` | Begriff gestrichelt `--tze-accent`, Def bg `#161616`, Linie links 3px | leseprobe |
| Leseprobe Seite | `.lp`, `.lp-hero`, `.lp-sec`, `.lp-story`, `.lp-note`, `.lp-kern`, `.lp-src`, `.lp-end`, `.lp-actions`, `.lp-back` | Seitenrahmen | Story ≤700px einspaltig | max 720px, Abschnitte Linie oben `#343434` | leseprobe |
| Hintergrundvideo | `.nt-bgvideo` | nur wissen.html | Reduced Motion: aus | `video` Deckkraft .38 + Verlauf `rgba(0,0,0,.55→.35→.8)` | wissen.html |
| Skip-Link | `.nt-skip`, `.skip-link` | Tastatur | `:focus` sichtbar | weiß auf schwarz, .75rem uppercase | alle |

### E2 · Welt 2 Stitch (`app.css`, klarheitscheck)

| Komponente | Klasse | Varianten / Zustände | Schlüsselwerte |
|---|---|---|---|
| Kopfzeile | `.bar`, `.bar-l/-r`, `.bar-tag`, `.icon-btn` | `.bar-tag` <640px aus; `.icon-btn span` ab 768px | fest, 56px, bg `#000`, Linie `#3c4a43`, Logo 32px |
| SOS-Knopf | `.sos-btn` | Hover bg `rgba(125,38,63,.4)` | min 40px, Rahmen `#7d263f`, bg `rgba(125,38,63,.2)`, Text `#ffb1c0`, Radius 4px |
| Karte | `.card` (`--hi`, `--crimson`), `.glow` | `--hi` Rahmen `rgba(98,240,189,.4)`; `--crimson` Verlauf 160deg | Padding 24px, bg `#0e131a`, Rahmen `rgba(255,255,255,.1)`, Radius 12px |
| Kicker | `.kicker` | in `.note--pink` pink | flex, Gap 8px, `#62f0bd` |
| Notiz | `.note` (`--pink`) | | Padding 16px, bg `#1b2027`, Linie links 2px `#62f0bd`, Radius `0 6px 6px 0` |
| Meta | `.meta` | 2 → 4 Spalten ab 640px | Felder bg `#171e28`, Radius 4px |
| Schritte | `.steps` | 5 → 3 Spalten ≤480px | Zahl 700 18px Space Grotesk `#62f0bd` |
| Knöpfe | `.btn` (`--block`, `--ghost`, `--crimson`) | Hover `#62f0bd`; aktiv scale(.98); `[disabled]` .4; Ghost Rahmen `rgba(255,255,255,.2)` → `#62f0bd`; Crimson `#7d263f` → `#96334f` | min 48px, Padding 12px 24px, bg `#3fd3a2`, Text `#000`, Radius 4px, Space Mono 12px |
| Navigation | `.navrow`, `.hint`, `.linkbtn` | | |
| Fortschritt | `.prog`, `.track i` | | 6px, Radius 999px, Füllung `#3fd3a2` |
| Eingabe | `.field`, `textarea.field`, `.flabel` | Fokus Rahmen `#62f0bd` + `0 0 0 2px rgba(98,240,189,.25)` | min 52px (textarea 96px), bg `#171e28`, Radius 4px |
| Chips | `.chips`, `.chip`, `.counter(.ok)` | `aria-pressed="true"` Rahmen `#62f0bd`, bg 10 %, „✓ “ | min 44px, Radius 4px, 500 15px/20px |
| Optionen | `.opts`, `.opt`, `.key` | `aria-pressed="true"` Rahmen `#62f0bd`, bg 8 % | Padding 16px, Radius 6px, Taste 24px Radius 3px |
| Split/Pane | `.split`, `.pane` (`--there` mint, `--wait` pink) | ≤480px 1 Spalte | Padding 16px, Radius 6px |
| Zitat | `.quote` | | s. C2 |
| Gegenüberstellung | `.vs` | | Radius 6px |
| Zyklus | `.cycle`, `.dots i(.on)`, `.cycle-title/-text` | `.on` pink | gestrichelt, Radius 8px |
| Kacheln | `.tiles`, `.tile` | Hover Rahmen `rgba(98,240,189,.4)` | Padding 12px, Radius 4px |
| Modal / Hotline | `.modal`, `.modal-box`, `.modal-x`, `.modal-head`, `.modal-ico`, `.hot`, `.num(--mint)` | `.hot:hover` Rahmen `#7d263f` | Overlay `rgba(0,0,0,.85)` + blur 4px; Box Rahmen `#7d263f`, Radius 12px; Nummer 700 20px `#ffb4ab` |
| Footer | `footer`, `footer nav` | ab 768px Zeile | Links Space Mono 11px, Hover `#62f0bd` |
| Sonst | `.book`, `.privacy`, `.about dl`, `.card-preview`, `.view` (fade) | | |

`tools/spielautomat.html` ist **nicht** Stitch, sondern Altdesign tools.css (Glas `rgba(11,16,26,.82)`, Knöpfe `.spin-btn` Radius 8px, `.rst-btn`) mit Nothing-Kopfzeile und Weiter-Block.

### E3 · Welt 3 Startseite (Hauptbausteine)

| Komponente | Klassen | Schlüsselwerte | Quelle |
|---|---|---|---|
| Kopfzeile | `#top.site-header`, `.header-beacon`, `-inner`, `-brand`, `-cta` | bg `#000`, Linie `#333` + 2px `--ub-c` Gold (`bereich.css`), Punktraster wie topnav, min 80px (mobil 68px), Wortmarke 72/52/44/32px; CTA Rahmen `#7d263f`, transparent, Space Mono .78rem, Preis in `[data-price]` zwischen Strichen `#333`, Hover bg `#7d263f` | index.html Inline `header-beacon-and-tile`, unbond-index-typo.css |
| Hero | `.hero`, `.hero-inner`, `.hero-eyebrow`, `h1`, `.hero-description`, `.hero-cta`, `.hero-secondary`, `.hero-scroll-link`, `.hero-quote-card…` | H1 `--ub-fs-h1`; Eyebrow Gold, Rahmen `rgba(210,166,59,.45)`; Hero-CTA von nothing-buttons **ausgenommen**, Breite auto, Padding-inline 24–26px [Farbe/Endwert unbekannt]; Akzent `#b6d7c0` | redesign-v32, glass-v33, unbond-unified, bereich |
| Knöpfe | `.button`, `.core-cta`, `.ed-cta`, `.price-cta`, `.lookinside-cta`, `.rc-modules-toggle`, `.akut-bruecke-btn`, `.cookie-button`, `.cookie-save` | wie Nothing-Primär: min 48px (Kauf 54px), Padding 11px 18px (Kauf 14px 24px), Rahmen `#7d263f`, bg `rgba(125,38,63,.13)`, Radius 4px, Space Mono, Hover gefüllt; Preis Gold zwischen Strichen `rgba(232,232,232,.30)` | unbond-nothing-buttons.css (überstimmt das ältere Inline-Vollbordeaux mit Rahmen `#a34b63`) |
| Preisbox | `#angebot .ed-card`, `.ed-top`, `.ed-badge`, `.ed-lead`, `.ed-body`, `.ed-stats`, `.ed-features`, `.ed-buy`, `.ed-price` (`strong`, `em` durchgestrichen), `.ed-once`, `.price-secondary`, `.ed-privacy` | max 860px, Padding clamp(22px,3.4vw,36px), Rahmen `rgba(226,232,228,.16)`, Radius 8px, bg `rgba(8,13,20,.86)`; Stats Gold; Häkchen `--bh-teal` → `#b6d7c0`; 2 Spalten 1.15fr/.85fr | unbond-below-hero.css |
| Autorinnen-Band | `.at-band`, `.at-photo`, `.at-fig` | Foto 76px rund, Rahmen 2px Gold; Zitat Playfair Italic; Caption Space Mono Gold | unbond-below-hero.css |
| Erkennungskarten | `.rc-card`, `.rc-plus` | 208px hoch, Radius 8px; `aria-expanded="true"` Rahmen `#7d263f` | unbond-below-hero.css |
| Programm-Phasen | `.phase` (`.is-open`), `.phase-toggle`, `.phase-plus`, `.phase-num`, `.phase-pain` | Radius 8px; offen: Plus bg `#7d263f`; Rahmen `rgba(182,215,192,.55)` | Inline + bereich |
| Schmerzpunkte | `unbond-painpoints.css` (`--pf-*`) | Karten 430px, Gold `#bc8e3b`, Sage `#5e9590` → `#b6d7c0` | unbond-painpoints.css |
| Perspektiven | `.perspectives-section--inline` | Video-Personas, Linie Teal → `#b6d7c0` | perspectives-v3.css/js |
| Blick ins Buch | `.lookinside-inner` | max 680px, Padding 34px 28px, Rahmen `rgba(210,166,59,.38)`, **Radius 18px**, blur 10px | Inline `sales-v34` |
| Wissens-Kachel | `.understand-tile`, `-kicker`, `-title`, `-meta`, `-go` | Raster mit Pfeilfeld 52px, Rahmen/Grün → `#b6d7c0`, bg `rgba(182,215,192,.13)`, Hover `#4f6b5a` | unbond-nothing-buttons.css + bereich |
| FAQ | `.faq-list details`, `.faq-question`, `.faq-chevron`, `.faq-answer-inner`, `.faq-number`, `.faq-kicker` | Frage .9rem/1.32 (mobil .86rem); Chevron Radius 4px, offen bg `#7d263f`; offene Zeile bg `rgba(182,215,192,.07)` | faq-chat-v7.css, Inline, bereich |
| Schluss-CTA | `#start .final-inner`, `.core-cta` | Rahmen oben `#b6d7c0` | unbond-final-cta.css, bereich |
| Footer | `.site-footer`, `.footer-grid`, `.footer-brand`, `.footer-legal`, `.footer-link`, `.footer-crisis` | 2 Spalten ab 900px; Logo 56px (mobil 48px) | site-v21, nothing-buttons, index-typo |
| Cookie | `#cookieBanner.cookie-bar`, `.cookie-bar-inner`, `.cookie-button`, `#cookieRejectAll` | **eigenes Markup**, nicht unbond-consent.css; fest unten, transparent; Ablehnen transparent mit Rahmen `#7d263f` | site-v21, glass-v33, Inline |
| Hintergrund | `.page-background` | Verläufe Mauve `rgba(199,154,183,.2)` + Sage `rgba(182,215,192,.12)` + `rgba(7,10,17,.32)` + `assets/bg-v22.webp` | bereich (Start) |

---

## F · Assets

| Datei / Ordner | Zweck | Nutzung |
|---|---|---|
| `assets/logo-wortmarke.webp` (301×114) | Wortmarke in Kopfzeile und Footer | 68 Referenzen, alle Welten (Stitch eigene Kopie `klarheitscheck/assets/logo-wortmarke.webp`) |
| `assets/logo.png` | Favicon (`rel="icon" type="image/png"`) auf allen Seiten | 36 Referenzen |
| `favicon.svg` | – | **nirgends referenziert** |
| `assets/icons/sm/*.webp/.png` | Icons für Weiter-Karten, Buch, Quellen, Hinweis; per CSS-Maske (`mask: var(--icon)`) eingefärbt | genutzt: icon-gluehbirne-puzzle, -auge-durchgestrichen, -verbindung.webp, -zielscheibe, -atom, -hand-blaetter2, -hand-schmetterling, -klinisch.webp, -fuersorge.webp; dazu 3 Dateien mit Prompt-Text als Namen (`create-one-standalone-icon…png`, `keep-the-same-…png` ×2) |
| `assets/icon-*.png` (Wurzel) | ältere Icons (atom, hand-blaetter, molekuel-blatt, zielscheibe) | nur index.html |
| Stitch-Icons | Inline-SVG-Sprite (`<symbol id="i-arrow_back" viewBox="0 -960 960 960">` …, Material-Symbols-Geometrie), `svg.ms` | klarheitscheck/index.html |
| `assets/sos.webp` | SOS-Icon im Notfall-Dialog | Tools (Stitch) |
| `assets/gefuehle/` (angst, ohnmacht, trauer, verzweiflung, wut .webp) | Gefühlsbilder als Kachel-Hintergrund `--tile-img` | wissen, klarheit, tools/phase-2 |
| `assets/personas/` (eva, lisa, mary, monika: .mp4, -poster.webp, .de.vtt, .transcript.txt) | Video-Perspektiven mit Untertiteln | index.html (perspectives-v3.js) |
| `assets/portraits/` (Kreislauf, Trauer, allein(-v2), contact(-v2), gas(-v2), kreislauf-v2, wut .png) | [unbekannt] | **keine Referenz gefunden** |
| `assets/videos/hintergrund.mp4`, `wissen-hintergrund.mp4` | Hintergrundvideos | hintergrund: index, Tests, Kompass, klarheit (auf nt-skin ausgeblendet); wissen-hintergrund: wissen.html |
| `assets/bg-v22.webp`, `bg-v22-mobile.webp` | Startseiten-Hintergrund | index |
| `assets/card-*.webp` (6 Dateien), `hero-final-first-frame.jpg` | [unbekannt] | **keine Referenz gefunden** |
| `assets/core-*.png`, `milena-author-close.webp`, `og-*.png`, `leseprobe-wolf-mary.webp`, `bloghintergrund.jpg/.png` | Produktbilder, Autorin, Social-Vorschau, Leseprobe, Blog | index, Report, Leseprobe, blog/index |
| Emoji | ☰ (Menü-Knopf, alle Seiten), 🍪 im Cookie-Titel (10 Seiten), ✦ ×8 und ✓ ×3 in no-contact/index.html, „✓ “ per CSS in Stitch-Chips, „↻“ im (ungenutzten) Kreislauf | |

---

## G · Inkonsistenzen

1. **Bordeaux in 6 Varianten:** `#7d263f`/`#96334f` (Nothing, Website-Regel) · `#6f2035`/`#862840` (style.css, unbond-shell.css, blick-ins-buch Block 1, Cookie-Banner `#6f2035`/Hover `#832640`) · `#6f2035`/`#832640` (tools.css) · `#6f2035`/`#872942` (site-v21) · `#7b233c` (glass-v33) · `#a34b63`/`#c26a82` (index Inline-Rahmen, überstimmt). Plus Weiter-Rot `#bc5470` (Toxikometer/Report), in keinem Token.
2. **Cookie-Banner ist nicht Nothing:** unbond-consent.css nutzt Navy-Glas (`rgba(20,27,40,.985)`, `#465064`, `#1d2534`, `#283246`), Radius 12/8/7px, Fokus **Gelb** `#f0c65d`, Checkbox `#85ab91`, Schrift 9–14px, Emoji 🍪. Startseite hat ein zweites, anderes Cookie-Markup (`.cookie-bar`).
3. **Grün in 9+ Werten:** `#5e9590` (Website kostenlos, nothing-alt, Weiter-„more“, Check-Count, Hinweis-Icon) · `#7a9e8a` (wissen `--ub-sig`, `.w-stage-proof` fest, Weiter No Contact) · `#85ab91` (Consent, tools.css, site-v21) · `#b6d7c0` (Start-Override) · `#159a82` (`--unbond-teal`, Fokus-Fallback) · `#a9c9b3` (glass) · `#6fb0a8` (Weiter Spielautomat, blog-Altvariable) · `#9cc7c1`/`#4a7a75`/`#4f6b5a` (Wissens-Kachel) · `#62f0bd`/`#3fd3a2` (Tools/Stitch).
4. **Mauve:** Regelwerk `#9B7FA4` (Weiter Narzissmus, Safety-Icon) gegen Bereich Klarheit `#B4869F` (auch `--hybrid-mauve`) gegen `#c79ab7` (glass, Start-Hintergrund).
5. **Terrakotta:** `#C97B63` (Bereich No Contact) gegen `#c4836e` (Weiter Bindung, Regelwerk) gegen `#c46a52` (tools.css).
6. **Gold/Gelb:** `#d2a63b` Standard, daneben `#e0b75a` (`--g-yellow`), `#e6c37b` (ux), `#bc8e3b` (painpoints), `#e7c596` (Kernsatz, auf nt-skin per Regel neutralisiert), `#e8c547` (`--yellow` blick), Fokusfarben `#f0c65d`, `#ffe0a1`. Verstößt gegen „Kein Gelb als UI-Farbe“.
7. **Textweiß in 7 Werten:** `#e8e8e8` · `#f1f3f0` · `#edebe6` · `#ecebe6` · `#f4f3ee` · `#f7f2ea` · `#dee2ed` (Stitch). Grau: `#a3a3a3`, `#8a8a8a`, `#b9b9b9`, `#5a5a5a`, `#3d3d3d`, `#929aaa`, `#bec4ce`.
8. **Radius-Regel 4/8px gebrochen:** Weiter 14px, Buch 16/18px + Knopf 8px, Quellen 12/10px, Consent 12/8/7px, Blick-ins-Buch-Box 18px, `--g-radius` 22px, Stitch 12/6/3/999px.
9. **Überschriften uneinheitlich:** Gewicht 400/500 (Nothing) gegen 600 (Weiter-H3, Buch-H2, Leseprobe, Stitch); Spacing -.015em gegen -.025em (Weiter, Buch, Leseprobe) gegen -.02em (Stitch, ed-card).
10. **Geladene, aber wirkungslose Schriften:** Nothing: Space Grotesk + Space Mono (.ttf) deklariert, durch Poppins-Override tot; Playfair 700 für `.w-num` deklariert, verliert gegen Poppins; `.tze-szenario__zitat` Playfair !important verliert ebenfalls (Spezifität, nicht im Browser geprüft). Startseite: Space Grotesk 300–700 deklariert, aber `unbond-index-typo.css` zwingt `inherit`; „Instrument Sans“ = Lato-Alias ungenutzt; Schriftgrößen in ~20 älteren Dateien und Inline (z. B. Hero-H1 clamp(2.05rem,4.1vw,3.22rem)) sind toter Code. Zwei Poppins-Dateisätze (`poppins-v24-latin-*` und `poppins-latin-*-normal`) parallel.
11. **Mehr als 3 Schriftfamilien pro Welt:** Startseite deklariert Poppins, Space Grotesk, Space Mono, Playfair, Instrument Serif/Sans (Aliase), Lato; wirksam 3. Stitch: Space Grotesk + Plus Jakarta Sans + Space Mono, **kein Poppins** → Markenbruch zur Website. Blick ins Buch: Poppins, Lato, Space Grotesk, Space Mono, Instrument Serif (base64) und „Playfair“ ohne „Display“ (nicht deklariert → fällt auf Georgia).
12. **Seiten außerhalb ihrer Welt:** blick-ins-buch.html lädt kein Nothing-CSS (Altdesign mit Navy `#0a0d14`, Glas, Nebula-Verlauf), hat keinen Trust/Topnav/Wegweiser, nur Footer und Zurück. tools/spielautomat.html hat kein `body.nt` → Poppins-Override und Nothing-Body greifen nicht, Lato/Playfair aus tools.css; außerdem `unbond-nothing-poppins.css` doppelt verlinkt. Klarheitscheck ohne `data-bereich`.
13. **Bereichsfarbe Tools = Stitch-Mint** `#62f0bd`, Stitch-Primärknopf ist Mint mit schwarzer Schrift statt Bordeaux.
14. **Fest eingetragene Farben statt Tokens:** unbond-bereich.css, unbond-footer.css, unbond-zurueck.css, unbond-weiter.css nutzen durchgehend Hex (`#343434`, `#e8e8e8`, `#a3a3a3`, `#000`, `#222`, `#7d263f`); nothing.css selbst hat `#343434`/`#0d0d0d` fest in `.nt-tile--locked:hover` und `.nt-phase`; weitere Einzelwerte `#050505` (Wegweiser), `#161616` (tze), `#5a5a5a` (Report-Bereich), `#333` (Raster, Kopfzeile Start).
15. **Doppelte Regeln:** Zeitstrahl-CSS steht in unbond-weg-tl.css **und** inline in wissen.html und tools/phase-2/index.html (laut Kommentar bekannt); `.nt-tile--img` ebenso.
16. **Toter Code:** `.nt-footer` (überall durch `.ub-footer` ersetzt), `.report-cycle*`/`.report-check-summary` (keine Verwendung), `.ub-ktests` (ersetzt durch `.ub-weg--tests`), Fortschrittsbalken-Farbe `#96334f` in skin wird von bereich.css überschrieben.
17. **Ungenutzte Assets:** favicon.svg, assets/portraits/ (10 Dateien), assets/card-*.webp (6), hero-final-first-frame.jpg, Prompt-benannte Icon-Dateien in assets/icons/sm.
18. **Spezifitäts-Hacks:** `:not(#w1)…`, `:not(#nb1):not(#nb2)`, `:not(#u1)…:not(#u8)`, `:not(#s1)…:not(#s3)`, `:not(#ub-x)` und flächendeckend `!important` in skin, bereich, buttons, index-typo, consent. Das Ergebnis jeder Änderung hängt von der Ladereihenfolge ab.
19. **Fokusfarbe nicht einheitlich:** `#fff` (Nothing) · `#e8e8e8` (tze) · `--ub-c` (Zurück) · `--c` (Weiter) · `#62f0bd` (Stitch) · `#b6d7c0`/`#159a82` (Start-Knöpfe) · `#f0c65d` (Cookie) · Gold (Blick).
20. **Gelöschte Signalfarbe auf Startseite:** `data-bereich="start"` setzt kein `--ub-sig`; Regelwerk sagt Salbeigrün, umgesetzt ist `#b6d7c0` per eigenem Block, nicht über `--ub-sig`.
