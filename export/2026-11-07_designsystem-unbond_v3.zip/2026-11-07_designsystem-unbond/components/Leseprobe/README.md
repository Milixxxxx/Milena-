Interaktive Leseprobe-Bausteine (`.tze`, Skill „Text zu Erlebnis UNBOND“) im Nothing-Design.

- Rahmen `.tze`: Grund `nt-surface`, Rahmen `nt-line`, Radius `radius-4`. Belastende Teile `.tze--schwer` mit 3px Linie `nt-red` links und Link „Diesen Teil überspringen“.
- Gewählter Knopf (`aria-pressed="true"`): Grund in Leitfarbe, Text schwarz.
- Muster: Vergleich (Umschalter mobil, nebeneinander ab 640px), Szenario mit Entscheidung, Glossar zum Antippen.
- Kernsatz `.lp-kern` in `web-kern`, Farbe `lp-kern`, Selektor ab `html body.nt`.
