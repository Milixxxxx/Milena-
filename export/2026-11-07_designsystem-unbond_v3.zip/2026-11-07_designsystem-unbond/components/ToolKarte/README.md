Karte `.card` mit Kicker, Titel, Einleitung und Hinweiskästen `.note`.

- Karte: Grund `tool-surface`, Haarlinie `tool-hair`, Radius `radius-12`, Innenabstand `space-tile`. Varianten `--hi` (Mint-Rahmen 40 %), `--crimson` (Verlauf).
- Kicker in `tool-caps`, Farbe `tool-primary`. Titel `tool-h-md`, Einleitung in `tool-text-var`.
- Hinweis `.note`: Grund `tool-sc`, 2px Linie links `tool-primary`; Warnung `.note--pink` in `tool-pink`.
