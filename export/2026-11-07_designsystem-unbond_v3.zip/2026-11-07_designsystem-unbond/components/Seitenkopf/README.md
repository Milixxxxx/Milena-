Seitenkopf `.nt-hero` aus Label, H1 mit Unterzeile und Einleitung.

- `.nt-label` in Versalien (`web-label`); das erste Label im Kopf trägt die Leitfarbe.
- H1 in `web-h1`, Gewicht 400, max 16 Zeichen breit. Die Unterzeile `h1 em` steht auf eigener Zeile in der Signalfarbe (`--ub-sig`).
- `.nt-lead` in `nt-text-2`, max 58ch.
- Abstand oben `space-hero-top`. Kein Bild, kein Verlauf.
