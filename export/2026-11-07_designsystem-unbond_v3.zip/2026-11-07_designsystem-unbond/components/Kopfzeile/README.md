Kopf jeder Website-Seite aus Krisenleiste (`.nt-trust`), Kopfzeile (`.topnav`) und Wegweiser (`.ub-weg`).

- Krisenleiste immer zuerst: „Kein Ersatz für Therapie“ und beide Hotlines als `tel:`-Links.
- Kopfzeile `space-nav` hoch, Grund `nt-black`, Linie `nt-line` plus 2px Leitfarbe (`--ub-c`) als `box-shadow: inset 0 -2px 0`. Punktraster rechts: `radial-gradient(#333 1px)` im 16px-Raster.
- Wortmarke 64px hoch (≤760px 48px). Menü: Wissen, Klarheit, Blog, No Contact, rechts „Zum Buch →“ als Bordeaux-Knopf.
- Aktiver Menüpunkt: `aria-current="page"`, weiß, 2px Unterstreichung in Leitfarbe, Offset 9px.
- Wegweiser „Dein Weg“ 00–04, aktiver Schritt `aria-current="step"` mit Unterkante in Leitfarbe. Mobil nur Nummern.
- Mobilmenü ab ≤1020px über `.menu-btn` (48×48) und `.mobile-panel.show`.
