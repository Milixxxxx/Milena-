Fortschritt, Mehrfachauswahl `.chip` und Einfachauswahl `.opt` der Tools.

- Fortschritt: „Schritt 02 / 05“ in `tool-caps`, Balken 6px, Füllung `tool-mint`, Radius `radius-pill`.
- Chips: Grund `tool-elevated`, min 44px, `aria-pressed="true"` Rahmen `tool-primary`, Häkchen davor.
- Optionen A/B/C: Radius `radius-6`, Taste 24px; gewählt Rahmen `tool-primary`, Grund 8 % Mint.
- Keine Punkte, Prozente oder Stufen als Ergebnis.
