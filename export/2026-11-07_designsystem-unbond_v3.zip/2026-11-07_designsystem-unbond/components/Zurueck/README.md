Zurück-Knopf `.ub-zurueck` am Seitenende links, direkt über dem Footer, auf allen Seiten außer der Startseite.

- Rahmen `nt-line`, Radius `radius-4`, min `space-touch`, Poppins 600 .9375rem.
- Hover und Fokus: Rahmen in Leitfarbe (`--ub-c`), ohne Bereich `nt-red-hover`.
- `unbond-zurueck.js`: kam die Besucherin von einer eigenen Seite, geht es per Verlauf zurück, sonst zum `href` (übergeordnete Seite).
