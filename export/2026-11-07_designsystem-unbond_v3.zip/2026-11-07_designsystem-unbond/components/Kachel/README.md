Einstiegskachel `.nt-tile` in Rastern (`.nt-tiles`) und im Zeitstrahl.

- Grund `nt-surface`, Rahmen `nt-line`, Radius `radius-8`, Innenabstand `space-tile`, min 340px hoch.
- Kopfzeile `.nt-tile-top` in `nt-text-3`, rechts eine Flagge `.nt-flag` („Hier starten“, „Soforthilfe“, „Erste Übung frei“, „Im Aufbau“).
- `--lead`: Rahmen `nt-red`, breitere Spalte. `--img`: Gefühlsbild über `--tile-img`, rechts unten, Deckkraft .36 (Hover .52). `--locked`: gestrichelt, kein Hover.
- Nummern `.w-num` immer in `nt-gold`.
- Hover: Rahmen `nt-red-hover`, `.nt-tile-go` füllt sich.
