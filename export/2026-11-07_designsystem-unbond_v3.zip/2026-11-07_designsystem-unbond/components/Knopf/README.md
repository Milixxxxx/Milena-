Knöpfe der Website: Bordeaux-Rahmen, transparent gefüllt, im Hover voll.

| Variante | Klasse | Einsatz |
|---|---|---|
| Primär | `.nt-btn` | Hauptaktion, „Zum Buch“, „Test starten“ |
| Groß | `.nt-btn--lg` | Hauptaktion am Seitenende; ≤640px volle Breite |
| Ghost | `.btn-sec`, `.btn-ghost` | Nebenaktion, zurück, PDF |

- Ruhe: Rahmen `nt-red`, Grund `rgba(125,38,63,.13)`, Text `nt-text`, `web-button` in Versalien, Radius `radius-4`, min 48px (groß 54px).
- Hover: Grund `nt-red`, Rahmen `nt-red-hover`, Text weiß. Fokus: 2px weiß, Offset 4px. Deaktiviert: Deckkraft .35.
- Knöpfe sind immer Bordeaux, nie Bereichsfarbe. Kein Türkis-Kaufknopf auf der Website.
