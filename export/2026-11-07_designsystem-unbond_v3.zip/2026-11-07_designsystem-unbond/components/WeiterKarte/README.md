Karte im Block „Wie geht es weiter?“ (`unbond-weiter.css/.js`) auf Tests, Report, Kompass.

- Jede Karte trägt die Farbe ihres Ziels in `--c`: `weiter-tox`, `weiter-narzissmus`, `weiter-bindung`, `weiter-kompass`, `weiter-spiel`, `weiter-nocontact`, Buch `nt-gold`.
- Nummer im 32px-Kreis, Icon 46px als CSS-Maske in `--c`, Kicker in Versalien, Titel `web-h3`.
- Grund `nt-surface`, Rahmen `nt-line`, Radius `radius-14` (bewusste Ausnahme). Hover: Rahmen `--c`, Grund 7 % `--c`, `translateY(-3px)`.
- Mobil senkrecht mit Linie links.
