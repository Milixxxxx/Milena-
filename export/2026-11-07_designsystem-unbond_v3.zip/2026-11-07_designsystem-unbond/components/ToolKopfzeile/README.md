Kopfzeile der Tools `.bar` mit Notfall-Knopf `.sos-btn`.

- Fest oben, 56px hoch, Grund `tool-deep`, Linie `tool-line`. Wortmarke 32px.
- Links „// Phase N · Name“ in `tool-caps`, `tool-outline` (unter 640px ausgeblendet).
- Rechts Notfall-Knopf: Rahmen `tool-crimson`, Grund `rgba(125,38,63,.2)`, Text `tool-pink`, öffnet den Notfall-Dialog. Pflicht in jedem Tool.
