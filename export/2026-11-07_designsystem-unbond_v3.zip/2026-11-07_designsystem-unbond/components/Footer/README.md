Einheitlicher Footer `.ub-footer` (`unbond-footer.css`) auf allen Unterseiten. Startseite und Tools haben noch eigene.

- Drei Spalten 1.3fr/1fr/1fr (≤760px zwei, ≤420px eine), Abstand 32px 48px.
- Wortmarke 132px breit, Unterzeile „von Milena · UNBOND“.
- Spaltentitel in `nt-gold`, Versalien. Links in `nt-text-2`, Unterstrich `nt-red`, Hover weiß.
- Unterste Zeile mit Krisenhinweis über Linie `nt-line-soft`.
