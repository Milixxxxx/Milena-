Knöpfe der Tools `.btn`.

| Variante | Klasse | Einsatz |
|---|---|---|
| Primär | `.btn` | Weiter, Starten: Grund `tool-mint`, Text schwarz, Hover `tool-primary` |
| Ghost | `.btn--ghost` | Zurück: Rahmen 20 % weiß, Hover `tool-primary` |
| Crimson | `.btn--crimson` | nur Löschen und Notfall |

- `tool-caps`-Schrift, min 48px, Padding 12px 24px, Radius `radius-4`, aktiv `scale(.98)`, deaktiviert .4.
