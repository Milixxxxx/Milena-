Preisbox `#angebot .ed-card` der Startseite (`unbond-below-hero.css`).

- Grund `start-panel`, Rahmen `rgba(226,232,228,.16)`, Radius `radius-8`, max 860px (zwei Spalten 1.15fr/.85fr).
- Preis in h2-Größe (`start-h2`) in `nt-gold`, alter Preis durchgestrichen in `nt-text-3`.
- Kaufknopf wie `Knopf` groß, Schrift Space Mono (`start-mono`). Der Link führt auf den Checkout ohne Gutschein-Parameter.
- Häkchen in `ub-start-sig`.
