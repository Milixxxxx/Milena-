Zickzack-Weg `.w-tl` aus `unbond-weg-tl.css`, ersetzt nebeneinanderstehende Kästen.

- Senkrechte Linie 1px `nt-line`, Füllung `nt-text` wächst mit dem Scrollen (`--w-tl-p`), Punkt 9px mit `shadow-tl-dot`.
- Jede Stufe `.w-stage`: Kachel und Text abwechselnd links und rechts, Abstand `space-stage`, Spaltenlücke 120px. ≤900px einspaltig, Linie links.
- Stufentitel `.w-stage-t` in `web-h2`, Nummer `.w-num` in `nt-gold`, Belegzeile `.w-stage-proof` mit 2px Linie in Signalfarbe.
- Einblendung .7s; bei reduzierter Bewegung sofort sichtbar.
