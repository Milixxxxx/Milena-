Notfall-Dialog `.modal` mit vier Nummern, Pflicht in jedem Tool.

- Overlay `rgba(0,0,0,.85)` mit 4px Unschärfe. Box: Grund `tool-surface`, Rahmen `tool-crimson`, Radius `radius-12`, Schatten `shadow-tool-modal`.
- Zeilen `.hot` als `tel:`-Links. 110 und 112 in `tool-error`, Beratungsnummern in `tool-mint` (Space Mono).
- `role="dialog"`, `aria-modal="true"`; Fokus wandert hinein und bleibt dort, Escape schließt, danach zurück zum Notfall-Knopf.
